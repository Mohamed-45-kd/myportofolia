/* @ds-bundle: {"format":4,"namespace":"MohamedWeliJamaDesignSystem_8944ce","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"SectionHeading","sourcePath":"components/core/SectionHeading.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ProjectCard","sourcePath":"components/data/ProjectCard.jsx"},{"name":"SkillMeter","sourcePath":"components/data/SkillMeter.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Timeline","sourcePath":"components/data/Timeline.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Toast","sourcePath":"components/feedback/Alert.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Radio","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Switch","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"LABEL","sourcePath":"components/forms/Input.jsx"},{"name":"Textarea","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Breadcrumbs","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Pagination","sourcePath":"components/navigation/Breadcrumbs.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Navbar","sourcePath":"components/navigation/Navbar.jsx"},{"name":"SidebarNav","sourcePath":"components/navigation/SidebarNav.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"4d5268e61862","components/core/Badge.jsx":"f0824fdc4437","components/core/Button.jsx":"5bc63866aa07","components/core/Card.jsx":"2179dd90b5f5","components/core/Divider.jsx":"cdc229bc8f90","components/core/Icon.jsx":"34771cbc0d7d","components/core/IconButton.jsx":"d489953d3fe5","components/core/Logo.jsx":"9dc146b5e026","components/core/SectionHeading.jsx":"357824d40e56","components/core/Tag.jsx":"99f5cdf5321b","components/data/ProjectCard.jsx":"a16a1be53105","components/data/SkillMeter.jsx":"5362ef45d525","components/data/StatCard.jsx":"de57a88c59dc","components/data/Table.jsx":"6b9c9a669a0e","components/data/Timeline.jsx":"47b2cf0e564a","components/feedback/Alert.jsx":"633c9f1e0228","components/feedback/EmptyState.jsx":"cfe11f5b0629","components/feedback/Modal.jsx":"a2f29d35f139","components/feedback/ProgressBar.jsx":"7b2d97bdb92a","components/feedback/Tooltip.jsx":"02fba8b5d893","components/forms/Checkbox.jsx":"b4f40eec9765","components/forms/Input.jsx":"3df70478c1f6","components/forms/Select.jsx":"611361273c89","components/navigation/Breadcrumbs.jsx":"5c465701746b","components/navigation/Footer.jsx":"a9f0c332d073","components/navigation/Navbar.jsx":"d51efffc5aee","components/navigation/SidebarNav.jsx":"6dfe4f3c0b5f","components/navigation/Tabs.jsx":"c523286fc1b5","ui_kits/dashboard/Screens.jsx":"c05ae030a674","ui_kits/dashboard/data.js":"ffccde9493a5","ui_kits/portfolio/Sections.jsx":"46e739cdb625","ui_kits/portfolio/data.js":"ce602c9a2209"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MohamedWeliJamaDesignSystem_8944ce = window.MohamedWeliJamaDesignSystem_8944ce || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  xs: 24,
  sm: 32,
  md: 40,
  lg: 56,
  xl: 88
};
function Avatar({
  src,
  name = '',
  size = 'md',
  ring = false,
  status,
  style,
  ...rest
}) {
  const px = typeof size === 'number' ? size : SIZES[size] || SIZES.md;
  const initials = name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex',
      flex: '0 0 auto',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: px,
      height: px,
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: src ? 'var(--surface-inset)' : 'var(--gradient-brand)',
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: Math.max(10, px * 0.38),
      letterSpacing: '0.02em',
      border: ring ? '2px solid var(--brand-primary)' : '1px solid var(--border-subtle)',
      boxShadow: ring ? 'var(--glow-accent)' : 'none'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: -1,
      bottom: -1,
      width: Math.max(8, px * 0.26),
      height: Math.max(8, px * 0.26),
      borderRadius: '50%',
      border: '2px solid var(--surface-card)',
      background: status === 'online' ? 'var(--success-500)' : status === 'busy' ? 'var(--warning-500)' : 'var(--text-faint)'
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  padding = 'md',
  interactive = false,
  glow = false,
  as = 'div',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const pad = {
    none: 0,
    sm: 'var(--space-4)',
    md: 'var(--space-6)',
    lg: 'var(--space-7)'
  }[padding] ?? 'var(--space-6)';
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    onMouseEnter: interactive ? () => setHover(true) : undefined,
    onMouseLeave: interactive ? () => setHover(false) : undefined,
    style: {
      position: 'relative',
      background: 'var(--surface-card)',
      border: `1px solid ${hover ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: pad,
      boxShadow: hover ? 'var(--shadow-lg), var(--inset-hairline-strong)' : `var(--shadow-sm), var(--inset-hairline)${glow ? ', var(--glow-accent)' : ''}`,
      transform: hover ? 'translateY(-3px)' : 'none',
      transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      cursor: interactive ? 'pointer' : undefined,
      textDecoration: 'none',
      color: 'inherit',
      ...style
    }
  }, rest), children);
}
function CardHeader({
  title,
  subtitle,
  action,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      marginBottom: 'var(--space-4)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, subtitle)), action);
}
Object.assign(__ds_scope, { Card, CardHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function Divider({
  label,
  orientation = 'horizontal',
  gradient = false,
  style
}) {
  const line = gradient ? 'linear-gradient(90deg,rgba(30,41,59,0) 0%,var(--border-strong) 50%,rgba(30,41,59,0) 100%)' : 'var(--border-subtle)';
  if (orientation === 'vertical') {
    return /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        width: 1,
        alignSelf: 'stretch',
        background: line,
        flex: '0 0 auto',
        ...style
      }
    });
  }
  if (!label) return /*#__PURE__*/React.createElement("hr", {
    style: {
      border: 'none',
      height: 1,
      background: line,
      margin: 0,
      ...style
    }
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: line
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-eyebrow)',
      color: 'var(--text-faint)',
      textTransform: 'uppercase'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: line
    }
  }));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide (CDN) is the brand icon set — 1.75px stroke, 24px grid, round caps.
   Loads the UMD build once, then hydrates any <i data-lucide> placeholder. */
let lucidePromise = null;
function ensureLucide() {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.lucide) return Promise.resolve();
  if (lucidePromise) return lucidePromise;
  lucidePromise = new Promise(res => {
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/lucide@0.454.0/dist/umd/lucide.min.js';
    s.onload = res;
    s.onerror = res;
    document.head.appendChild(s);
  });
  return lucidePromise;
}
function Icon({
  name,
  size = 20,
  stroke = 1.75,
  color = 'currentColor',
  style,
  ...rest
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    let dead = false;
    ensureLucide().then(() => {
      if (dead || !ref.current || !window.lucide) return;
      ref.current.innerHTML = '';
      const el = document.createElement('i');
      el.setAttribute('data-lucide', name);
      ref.current.appendChild(el);
      window.lucide.createIcons({
        icons: window.lucide.icons,
        nameAttr: 'data-lucide',
        attrs: {
          width: size,
          height: size,
          'stroke-width': stroke,
          stroke: color,
          'stroke-linecap': 'round',
          'stroke-linejoin': 'round'
        },
        root: ref.current
      });
    });
    return () => {
      dead = true;
    };
  }, [name, size, stroke, color]);
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      flex: '0 0 auto',
      color,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  brand: {
    bg: 'rgba(10,132,255,.12)',
    fg: 'var(--brand-accent)',
    bd: 'rgba(10,132,255,.30)'
  },
  neutral: {
    bg: 'var(--surface-inset)',
    fg: 'var(--text-muted)',
    bd: 'var(--border-subtle)'
  },
  success: {
    bg: 'var(--success-surface)',
    fg: 'var(--success-500)',
    bd: 'rgba(34,211,154,.30)'
  },
  warning: {
    bg: 'var(--warning-surface)',
    fg: 'var(--warning-500)',
    bd: 'rgba(255,176,32,.30)'
  },
  danger: {
    bg: 'var(--danger-surface)',
    fg: 'var(--danger-500)',
    bd: 'rgba(255,77,94,.30)'
  }
};
function Badge({
  children,
  tone = 'neutral',
  size = 'md',
  dot = false,
  icon,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: sm ? 5 : 6,
      height: sm ? 20 : 24,
      padding: sm ? '0 7px' : '0 10px',
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}`,
      fontFamily: 'var(--font-body)',
      fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.fg,
      flex: '0 0 auto'
    }
  }), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: sm ? 11 : 13
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    h: 34,
    px: 'var(--space-3)',
    fs: 'var(--text-sm)',
    gap: 6,
    icon: 15
  },
  md: {
    h: 42,
    px: 'var(--space-5)',
    fs: 'var(--text-sm)',
    gap: 8,
    icon: 17
  },
  lg: {
    h: 52,
    px: 'var(--space-7)',
    fs: 'var(--text-md)',
    gap: 10,
    icon: 19
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--gradient-brand)',
    color: '#fff',
    border: '1px solid transparent',
    boxShadow: 'var(--glow-brand)'
  },
  secondary: {
    background: 'var(--surface-card)',
    color: 'var(--text-primary)',
    border: '1px solid var(--border-subtle)',
    boxShadow: 'var(--inset-hairline)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--text-secondary)',
    border: '1px solid transparent',
    boxShadow: 'none'
  },
  outline: {
    background: 'transparent',
    color: 'var(--brand-primary)',
    border: '1px solid var(--border-brand)',
    boxShadow: 'none'
  },
  danger: {
    background: 'var(--danger-500)',
    color: '#fff',
    border: '1px solid transparent',
    boxShadow: '0 8px 24px -10px rgba(255,77,94,.7)'
  }
};
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  disabled = false,
  loading = false,
  fullWidth = false,
  as = 'button',
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const off = disabled || loading;
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    onClick: off ? undefined : onClick,
    disabled: Tag === 'button' ? off : undefined,
    "aria-busy": loading || undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      height: s.h,
      padding: `0 ${s.px}`,
      borderRadius: 'var(--radius-md)',
      fontFamily: 'var(--font-body)',
      fontSize: s.fs,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--track-snug)',
      whiteSpace: 'nowrap',
      cursor: off ? 'not-allowed' : 'pointer',
      opacity: off ? 0.45 : 1,
      textDecoration: 'none',
      transition: 'transform var(--dur-fast) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard), background var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      transform: off ? 'none' : press ? 'scale(.985)' : hover ? 'translateY(-2px)' : 'none',
      ...v,
      ...(hover && !off && variant === 'primary' ? {
        boxShadow: 'var(--glow-brand-strong)'
      } : null),
      ...(hover && !off && variant === 'secondary' ? {
        background: 'var(--surface-hover)',
        borderColor: 'var(--border-strong)'
      } : null),
      ...(hover && !off && variant === 'ghost' ? {
        background: 'var(--surface-hover)',
        color: 'var(--text-primary)'
      } : null),
      ...(hover && !off && variant === 'outline' ? {
        background: 'rgba(10,132,255,.10)',
        borderColor: 'var(--brand-primary)'
      } : null),
      ...style
    }
  }, rest), loading ? /*#__PURE__*/React.createElement(Spinner, {
    size: s.icon
  }) : icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }) : null, children, iconRight && !loading ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }) : null);
}
function Spinner({
  size
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      flex: '0 0 auto',
      border: '2px solid rgba(255,255,255,.28)',
      borderTopColor: 'currentColor',
      animation: 'mwj-spin .7s linear infinite'
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes mwj-spin{to{transform:rotate(360deg)}}'));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const BOX = {
  sm: 32,
  md: 38,
  lg: 46
};
function IconButton({
  icon,
  label,
  variant = 'secondary',
  size = 'md',
  active = false,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const box = BOX[size] || BOX.md;
  const base = variant === 'ghost' ? {
    background: 'transparent',
    border: '1px solid transparent',
    color: 'var(--text-muted)'
  } : variant === 'primary' ? {
    background: 'var(--gradient-brand)',
    border: '1px solid transparent',
    color: '#fff',
    boxShadow: 'var(--glow-brand)'
  } : {
    background: 'var(--surface-card)',
    border: '1px solid var(--border-subtle)',
    color: 'var(--text-secondary)',
    boxShadow: 'var(--inset-hairline)'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    "aria-pressed": active || undefined,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    title: label,
    style: {
      width: box,
      height: box,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'background var(--dur-base) var(--ease-standard), color var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
      ...base,
      ...(active ? {
        background: 'rgba(10,132,255,.14)',
        borderColor: 'var(--border-brand)',
        color: 'var(--brand-accent)'
      } : null),
      ...(hover && !disabled && !active ? {
        background: 'var(--surface-hover)',
        color: 'var(--text-primary)',
        borderColor: variant === 'ghost' ? 'transparent' : 'var(--border-strong)'
      } : null),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 15 : size === 'lg' ? 20 : 17
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* The MWJ monogram lockup. The provided artwork is a raster lockup on near-black,
   so the mark is used as an <img>; the wordmark next to it is live type. */
function Logo({
  src = 'assets/logo-lockup.png',
  variant = 'lockup',
  size = 36,
  showMission = false,
  style,
  ...rest
}) {
  if (variant === 'mark') {
    return /*#__PURE__*/React.createElement("img", _extends({
      src: src,
      alt: "Mohamed Weli Jama",
      style: {
        width: size,
        height: size,
        objectFit: 'cover',
        objectPosition: 'center 22%',
        borderRadius: 'var(--radius-sm)',
        ...style
      }
    }, rest));
  }
  if (variant === 'wordmark') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'grid',
        gap: 2,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 'var(--weight-bold)',
        fontSize: size * 0.44,
        letterSpacing: 'var(--track-eyebrow)',
        color: 'var(--text-primary)',
        lineHeight: 1
      }
    }, "MOHAMED"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 'var(--weight-bold)',
        fontSize: size * 0.44,
        letterSpacing: 'var(--track-eyebrow)',
        lineHeight: 1,
        background: 'var(--gradient-brand)',
        WebkitBackgroundClip: 'text',
        backgroundClip: 'text',
        color: 'transparent'
      }
    }, "WELI JAMA"));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "",
    style: {
      width: size,
      height: size,
      objectFit: 'cover',
      objectPosition: 'center 22%',
      borderRadius: 'var(--radius-sm)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: showMission ? 3 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 13,
      letterSpacing: '0.16em',
      color: 'var(--text-primary)',
      lineHeight: 1
    }
  }, "MOHAMED WELI JAMA"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.12em',
      color: 'var(--text-muted)',
      lineHeight: 1.3
    }
  }, showMission ? 'MY MISSION IS TO DIGITALIZE OUR COUNTRY' : 'SOFTWARE & WEB DEVELOPER')));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeading.jsx
try { (() => {
function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
  action,
  style
}) {
  const center = align === 'center';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      textAlign: center ? 'center' : 'left',
      justifyItems: center ? 'center' : 'start',
      maxWidth: center ? 720 : undefined,
      margin: center ? '0 auto' : undefined,
      ...style
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--track-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--brand-accent)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 1,
      background: 'var(--brand-primary)'
    }
  }), eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      width: '100%',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-tight)',
      lineHeight: 1.1,
      margin: 0
    }
  }, title), action), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)',
      maxWidth: 640
    }
  }, description));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  active = false,
  onRemove,
  onClick,
  size = 'md',
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick;
  const sm = size === 'sm';
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: sm ? 24 : 30,
      padding: sm ? '0 9px' : '0 12px',
      borderRadius: 'var(--radius-sm)',
      background: active ? 'rgba(10,132,255,.12)' : hover && interactive ? 'var(--surface-hover)' : 'var(--surface-inset)',
      border: `1px solid ${active ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
      color: active ? 'var(--brand-accent)' : 'var(--text-secondary)',
      fontFamily: 'var(--font-mono)',
      fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: '0.01em',
      cursor: interactive ? 'pointer' : 'default',
      whiteSpace: 'nowrap',
      transition: 'all var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: 'inline-flex',
      background: 'none',
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      color: 'inherit',
      opacity: .65
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 12
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/ProjectCard.jsx
try { (() => {
function ProjectCard({
  title,
  summary,
  thumbnail,
  tags = [],
  status,
  year,
  featured = false,
  onOpen,
  style
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    interactive: true,
    padding: "none",
    glow: featured,
    onClick: onOpen,
    style: {
      overflow: 'hidden',
      display: 'grid',
      gridTemplateRows: 'auto 1fr',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '16/10',
      background: thumbnail ? `center/cover no-repeat url(${thumbnail})` : 'var(--surface-inset)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, !thumbnail && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeItems: 'center',
      gap: 6,
      color: 'var(--text-faint)',
      backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)',
      backgroundSize: '28px 28px'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "image",
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)'
    }
  }, "SCREENSHOT")), (status || featured) && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'var(--space-3)',
      left: 'var(--space-3)',
      display: 'flex',
      gap: 6
    }
  }, featured && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "brand",
    size: "sm",
    icon: "star"
  }, "Featured"), status && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "neutral",
    size: "sm"
  }, status))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      padding: 'var(--space-5)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, title), year && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, year)), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, summary), tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6,
      marginTop: 2
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t,
    size: "sm"
  }, t))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 'var(--space-2)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--brand-accent)'
    }
  }, "Read case study ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-up-right",
    size: 15
  }))));
}
Object.assign(__ds_scope, { ProjectCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProjectCard.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function StatCard({
  label,
  value,
  delta,
  deltaTone = 'success',
  icon,
  footnote,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      display: 'grid',
      gap: 'var(--space-3)',
      padding: 'var(--space-5)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-sm), var(--inset-hairline)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--gradient-card-edge)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-sm)',
      background: 'rgba(10,132,255,.10)',
      border: '1px solid var(--border-brand)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 16,
    color: "var(--brand-accent)"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-3xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-tight)',
      lineHeight: 1
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: `var(--${deltaTone}-500)`
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: deltaTone === 'danger' ? 'trending-down' : 'trending-up',
    size: 13
  }), delta)), footnote && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, footnote));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function Table({
  columns = [],
  rows = [],
  onSort,
  sort,
  dense = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      overflow: 'hidden',
      background: 'var(--surface-card)',
      boxShadow: 'var(--inset-hairline)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-body)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    onClick: c.sortable && onSort ? () => onSort(c.key) : undefined,
    style: {
      textAlign: c.align || 'left',
      padding: dense ? '10px 14px' : '13px 18px',
      background: 'var(--surface-inset)',
      borderBottom: '1px solid var(--border-subtle)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      whiteSpace: 'nowrap',
      cursor: c.sortable ? 'pointer' : 'default',
      width: c.width
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, c.label, c.sortable && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: sort === c.key ? 'chevron-up' : 'chevrons-up-down',
    size: 12,
    color: sort === c.key ? 'var(--brand-accent)' : 'var(--text-faint)'
  })))))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement(Row, {
    key: r.id ?? i,
    row: r,
    columns: columns,
    dense: dense,
    last: i === rows.length - 1
  })))));
}
function Row({
  row,
  columns,
  dense,
  last
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("tr", {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: hover ? 'var(--surface-hover)' : 'transparent',
      transition: 'background var(--dur-fast) var(--ease-standard)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: dense ? '10px 14px' : '15px 18px',
      borderBottom: last ? 'none' : '1px solid var(--border-subtle)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      verticalAlign: 'middle'
    }
  }, c.render ? c.render(row) : row[c.key])));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/data/Timeline.jsx
try { (() => {
function Timeline({
  items = [],
  style
}) {
  return /*#__PURE__*/React.createElement("ol", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'grid',
      gap: 'var(--space-7)',
      ...style
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("li", {
    key: it.id || i,
    style: {
      display: 'grid',
      gridTemplateColumns: '34px 1fr',
      gap: 'var(--space-5)',
      position: 'relative'
    }
  }, i < items.length - 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 17,
      top: 36,
      bottom: -32,
      width: 1,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-sm)',
      background: it.current ? 'rgba(10,132,255,.12)' : 'var(--surface-inset)',
      border: `1px solid ${it.current ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon || 'briefcase',
    size: 16,
    color: it.current ? 'var(--brand-accent)' : 'var(--text-muted)'
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6,
      paddingBottom: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-3)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, it.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, it.period)), it.org && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--brand-accent)',
      fontWeight: 'var(--weight-medium)'
    }
  }, it.org), it.description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-relaxed)',
      maxWidth: 620
    }
  }, it.description), it.tags && it.tags.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6,
      marginTop: 4
    }
  }, it.tags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t,
    size: "sm"
  }, t)))))));
}
Object.assign(__ds_scope, { Timeline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Timeline.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const TONES = {
  info: {
    fg: 'var(--info-500)',
    bg: 'var(--info-surface)',
    bd: 'rgba(0,194,255,.28)',
    icon: 'info'
  },
  success: {
    fg: 'var(--success-500)',
    bg: 'var(--success-surface)',
    bd: 'rgba(34,211,154,.28)',
    icon: 'check-circle-2'
  },
  warning: {
    fg: 'var(--warning-500)',
    bg: 'var(--warning-surface)',
    bd: 'rgba(255,176,32,.28)',
    icon: 'alert-triangle'
  },
  danger: {
    fg: 'var(--danger-500)',
    bg: 'var(--danger-surface)',
    bd: 'rgba(255,77,94,.28)',
    icon: 'alert-octagon'
  }
};
function Alert({
  tone = 'info',
  title,
  children,
  onDismiss,
  action,
  style
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", {
    role: tone === 'danger' ? 'alert' : 'status',
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)',
      background: t.bg,
      border: `1px solid ${t.bd}`,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      marginTop: 1
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 18,
    color: t.fg
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      lineHeight: 'var(--leading-normal)'
    }
  }, children), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, action)), onDismiss && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onDismiss,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      padding: 0,
      height: 18
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
function Toast({
  tone = 'success',
  title,
  children,
  onDismiss,
  style
}) {
  const t = TONES[tone] || TONES.success;
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      minWidth: 300,
      maxWidth: 420,
      padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-lg), var(--inset-hairline)',
      backdropFilter: 'var(--blur-sm)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 3,
      alignSelf: 'stretch',
      borderRadius: 3,
      background: t.fg,
      flex: '0 0 auto'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 18,
    color: t.fg
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 2,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, title), children && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, children)), onDismiss && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onDismiss,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-faint)',
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 15
  })));
}
Object.assign(__ds_scope, { Alert, Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = 'inbox',
  title,
  description,
  action,
  compact = false,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      justifyItems: 'center',
      gap: 'var(--space-3)',
      textAlign: 'center',
      padding: compact ? 'var(--space-7)' : 'var(--space-11) var(--space-7)',
      border: '1px dashed var(--border-strong)',
      borderRadius: 'var(--radius-lg)',
      background: 'var(--surface-inset)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 46,
      height: 46,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-md)',
      background: 'rgba(10,132,255,.10)',
      border: '1px solid var(--border-brand)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 21,
    color: "var(--brand-accent)"
  })), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      maxWidth: 360,
      lineHeight: 'var(--leading-normal)'
    }
  }, description), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-2)'
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
function Modal({
  open,
  title,
  description,
  children,
  footer,
  onClose,
  width = 520,
  style
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape' && onClose) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": typeof title === 'string' ? title : undefined,
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 90,
      display: 'grid',
      placeItems: 'center',
      padding: 'var(--space-6)',
      background: 'var(--surface-overlay)',
      backdropFilter: 'var(--blur-md)',
      WebkitBackdropFilter: 'var(--blur-md)',
      animation: 'mwj-fade var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes mwj-fade{from{opacity:0}to{opacity:1}}@keyframes mwj-rise{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}'), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl), var(--inset-hairline-strong)',
      overflow: 'hidden',
      animation: 'mwj-rise var(--dur-slow) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-4)',
      padding: 'var(--space-6) var(--space-6) var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 5,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      lineHeight: 'var(--leading-normal)'
    }
  }, description)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    variant: "ghost",
    size: "sm",
    onClick: onClose
  })), children && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 var(--space-6) var(--space-6)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-3)',
      padding: 'var(--space-5) var(--space-6)',
      background: 'var(--surface-inset)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  label,
  showValue = false,
  size = 'md',
  tone = 'brand',
  style
}) {
  const h = size === 'sm' ? 4 : size === 'lg' ? 10 : 6;
  const fill = tone === 'brand' ? 'var(--gradient-brand)' : `var(--${tone}-500)`;
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...style
    }
  }, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      fontWeight: 'var(--weight-medium)'
    }
  }, label), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--brand-accent)'
    }
  }, pct, "%")), /*#__PURE__*/React.createElement("div", {
    role: "progressbar",
    "aria-valuenow": pct,
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      height: h,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--surface-inset)',
      border: '1px solid var(--border-subtle)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: pct + '%',
      height: '100%',
      background: fill,
      borderRadius: 'var(--radius-pill)',
      boxShadow: 'var(--glow-accent)',
      transition: 'width var(--dur-slower) var(--ease-out)'
    }
  })));
}
function Skeleton({
  width = '100%',
  height = 14,
  radius = 'var(--radius-sm)',
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      width,
      height,
      borderRadius: radius,
      background: 'linear-gradient(90deg,var(--surface-inset) 0%,var(--surface-hover) 50%,var(--surface-inset) 100%)',
      backgroundSize: '200% 100%',
      animation: 'mwj-shimmer 1.4s var(--ease-standard) infinite',
      ...style
    }
  }, /*#__PURE__*/React.createElement("style", null, '@keyframes mwj-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}'));
}
Object.assign(__ds_scope, { ProgressBar, Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/data/SkillMeter.jsx
try { (() => {
function SkillMeter({
  name,
  level,
  icon,
  note,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      padding: 'var(--space-4) var(--space-5)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--inset-hairline)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 17,
    color: "var(--brand-accent)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, level, "%")), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: level,
    size: "sm"
  }), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, note));
}
Object.assign(__ds_scope, { SkillMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/SkillMeter.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  children,
  placement = 'top',
  style
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translate(-50%,-8px)'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translate(-50%,8px)'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translate(-8px,-50%)'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translate(8px,-50%)'
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      zIndex: 60,
      ...pos,
      whiteSpace: 'nowrap',
      padding: '6px 10px',
      borderRadius: 'var(--radius-sm)',
      background: 'var(--ink-800)',
      border: '1px solid var(--border-strong)',
      boxShadow: 'var(--shadow-md)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: '.02em',
      pointerEvents: 'none',
      ...style
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  description,
  checked,
  onChange,
  disabled,
  id,
  style
}) {
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: uid,
    type: "checkbox",
    checked: !!checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked, e),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: '0 0 auto',
      marginTop: 2,
      borderRadius: 'var(--radius-xs)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: checked ? 'var(--gradient-brand)' : 'var(--surface-inset)',
      border: `1px solid ${checked ? 'transparent' : 'var(--border-strong)'}`,
      boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 13,
    stroke: 3,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, description)));
}
function Radio({
  label,
  description,
  checked,
  onChange,
  name,
  value,
  disabled,
  id,
  style
}) {
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    id: uid,
    type: "radio",
    name: name,
    value: value,
    checked: !!checked,
    disabled: disabled,
    onChange: e => onChange && onChange(value, e),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: '0 0 auto',
      marginTop: 2,
      borderRadius: '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--surface-inset)',
      border: `1px solid ${checked ? 'var(--brand-primary)' : 'var(--border-strong)'}`,
      boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--gradient-brand)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, description)));
}
function Switch({
  label,
  checked,
  onChange,
  disabled,
  size = 'md',
  style
}) {
  const w = size === 'sm' ? 34 : 44,
    h = size === 'sm' ? 20 : 25,
    k = h - 6;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!checked,
    disabled: disabled,
    role: "switch",
    onChange: e => onChange && onChange(e.target.checked, e),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: w,
      height: h,
      borderRadius: 'var(--radius-pill)',
      flex: '0 0 auto',
      position: 'relative',
      background: checked ? 'var(--gradient-brand)' : 'var(--surface-inset)',
      border: `1px solid ${checked ? 'transparent' : 'var(--border-strong)'}`,
      boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
      transition: 'all var(--dur-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? w - k - 4 : 2,
      width: k,
      height: k,
      borderRadius: '50%',
      background: checked ? '#fff' : 'var(--text-muted)',
      transition: 'left var(--dur-base) var(--ease-spring), background var(--dur-base) var(--ease-standard)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox, Radio, Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  icon,
  suffix,
  size = 'md',
  id,
  style,
  containerStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  const h = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: LABEL
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      height: h,
      padding: '0 var(--space-4)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)',
      border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
      boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
      transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)'
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 17,
    color: focus ? 'var(--brand-accent)' : 'var(--text-faint)'
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: uid,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    "aria-invalid": !!error,
    "aria-describedby": hint || error ? uid + '-d' : undefined,
    style: {
      flex: 1,
      minWidth: 0,
      background: 'none',
      border: 'none',
      outline: 'none',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-base)',
      ...style
    }
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, suffix)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    id: uid + '-d',
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger-500)' : 'var(--text-faint)'
    }
  }, error || hint));
}
const LABEL = {
  fontFamily: 'var(--font-body)',
  fontSize: 'var(--text-xs)',
  fontWeight: 'var(--weight-semibold)',
  letterSpacing: 'var(--track-wide)',
  textTransform: 'uppercase',
  color: 'var(--text-muted)'
};
function Textarea({
  label,
  hint,
  error,
  rows = 4,
  id,
  style,
  containerStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: LABEL
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: uid,
    rows: rows,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    "aria-invalid": !!error,
    style: {
      padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)',
      border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
      boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-normal)',
      outline: 'none',
      resize: 'vertical',
      transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger-500)' : 'var(--text-faint)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input, LABEL, Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  hint,
  error,
  options = [],
  size = 'md',
  id,
  style,
  containerStyle,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  const h = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: uid,
    style: __ds_scope.LABEL
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: uid,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      width: '100%',
      height: h,
      padding: '0 var(--space-9) 0 var(--space-4)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)',
      border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
      boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-base)',
      outline: 'none',
      cursor: 'pointer',
      transition: 'border-color var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v,
      style: {
        background: 'var(--surface-card)'
      }
    }, l);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 'var(--space-4)',
      pointerEvents: 'none',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--text-muted)"
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger-500)' : 'var(--text-faint)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumbs.jsx
try { (() => {
function Breadcrumbs({
  items = [],
  onNavigate,
  style
}) {
  return /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Breadcrumb",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      flexWrap: 'wrap',
      ...style
    }
  }, items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: it.id || it.label
    }, last ? /*#__PURE__*/React.createElement("span", {
      "aria-current": "page",
      style: {
        fontSize: 'var(--text-sm)',
        color: 'var(--text-primary)',
        fontWeight: 'var(--weight-medium)'
      }
    }, it.label) : /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNavigate && onNavigate(it.id);
      },
      style: {
        fontSize: 'var(--text-sm)',
        color: 'var(--text-muted)',
        textDecoration: 'none'
      }
    }, it.label), !last && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "chevron-right",
      size: 14,
      color: "var(--text-faint)"
    }));
  }));
}
function Pagination({
  page = 1,
  pages = 1,
  onChange,
  style
}) {
  const nums = [];
  for (let i = 1; i <= pages; i++) nums.push(i);
  const shown = pages <= 7 ? nums : nums.filter(n => n === 1 || n === pages || Math.abs(n - page) <= 1);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      ...style
    }
  }, /*#__PURE__*/React.createElement(PagBtn, {
    disabled: page <= 1,
    onClick: () => onChange && onChange(page - 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 15
  })), shown.map((n, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: n
  }, i > 0 && n - shown[i - 1] > 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-faint)',
      fontSize: 'var(--text-sm)',
      padding: '0 2px'
    }
  }, "\u2026"), /*#__PURE__*/React.createElement(PagBtn, {
    active: n === page,
    onClick: () => onChange && onChange(n)
  }, n))), /*#__PURE__*/React.createElement(PagBtn, {
    disabled: page >= pages,
    onClick: () => onChange && onChange(page + 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 15
  })));
}
function PagBtn({
  children,
  active,
  disabled,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: onClick,
    style: {
      minWidth: 34,
      height: 34,
      padding: '0 8px',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .4 : 1,
      background: active ? 'rgba(10,132,255,.14)' : 'var(--surface-card)',
      border: `1px solid ${active ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
      color: active ? 'var(--brand-accent)' : 'var(--text-secondary)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, children);
}
Object.assign(__ds_scope, { Breadcrumbs, Pagination });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumbs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function Footer({
  columns = [],
  socials = [],
  logoSrc,
  note,
  style
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--bg-subtle)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--layout-max)',
      margin: '0 auto',
      padding: 'var(--space-11) var(--layout-gutter) var(--space-7)',
      display: 'grid',
      gap: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr repeat(auto-fit,minmax(140px,1fr))',
      gap: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    size: 38,
    src: logoSrc,
    showMission: true
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      maxWidth: 300,
      lineHeight: 'var(--leading-relaxed)'
    }
  }, note), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, socials.map(s => /*#__PURE__*/React.createElement("a", {
    key: s.icon,
    href: s.href || '#',
    "aria-label": s.label,
    style: {
      width: 36,
      height: 36,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border-subtle)',
      background: 'var(--surface-card)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: s.icon,
    size: 16
  }))))), columns.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.title,
    style: {
      display: 'grid',
      gap: 'var(--space-3)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, c.title), c.links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.label,
    href: l.href || '#',
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      textDecoration: 'none'
    }
  }, l.label))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-4)',
      justifyContent: 'space-between',
      paddingTop: 'var(--space-6)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, "\xA9 ", new Date().getFullYear(), " Mohamed Weli Jama"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, "Built and maintained by hand"))));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Navbar.jsx
try { (() => {
function Navbar({
  items = [],
  active,
  onNavigate,
  logoSrc,
  cta,
  onToggleTheme,
  theme = 'dark',
  style
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 40,
      height: 'var(--nav-h)',
      display: 'flex',
      alignItems: 'center',
      background: scrolled ? 'color-mix(in srgb, var(--bg-base) 78%, transparent)' : 'transparent',
      backdropFilter: scrolled ? 'var(--blur-md)' : 'none',
      WebkitBackdropFilter: scrolled ? 'var(--blur-md)' : 'none',
      borderBottom: `1px solid ${scrolled ? 'var(--border-subtle)' : 'transparent'}`,
      transition: 'all var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 'var(--layout-max)',
      margin: '0 auto',
      padding: '0 var(--layout-gutter)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(items[0] && items[0].id);
    },
    style: {
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    size: 34,
    src: logoSrc
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-1)',
      marginLeft: 'auto'
    }
  }, items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("a", {
      key: it.id,
      href: it.href || '#',
      onClick: e => {
        e.preventDefault();
        onNavigate && onNavigate(it.id);
      },
      style: {
        position: 'relative',
        padding: '8px 12px',
        borderRadius: 'var(--radius-sm)',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-medium)',
        color: on ? 'var(--text-primary)' : 'var(--text-muted)',
        textDecoration: 'none',
        transition: 'color var(--dur-fast) var(--ease-standard)'
      }
    }, it.label, on && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 12,
        right: 12,
        bottom: 2,
        height: 2,
        borderRadius: 2,
        background: 'var(--gradient-brand)',
        boxShadow: 'var(--glow-accent)'
      }
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, onToggleTheme && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: theme === 'dark' ? 'sun' : 'moon',
    label: "Toggle theme",
    variant: "ghost",
    onClick: onToggleTheme
  }), cta && /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    iconRight: "arrow-up-right",
    onClick: cta.onClick
  }, cta.label))));
}
Object.assign(__ds_scope, { Navbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Navbar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarNav.jsx
try { (() => {
function SidebarNav({
  groups = [],
  active,
  onNavigate,
  logoSrc,
  collapsed = false,
  footer,
  style
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: collapsed ? 'var(--sidebar-w-collapsed)' : 'var(--sidebar-w)',
      flex: '0 0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      background: 'var(--surface-raised)',
      borderRight: '1px solid var(--border-subtle)',
      padding: 'var(--space-5) var(--space-4)',
      height: '100%',
      overflowY: 'auto',
      transition: 'width var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 var(--space-2)'
    }
  }, collapsed ? /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    variant: "mark",
    size: 32,
    src: logoSrc
  }) : /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    size: 32,
    src: logoSrc
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, groups.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.label || 'g',
    style: {
      display: 'grid',
      gap: 4
    }
  }, g.label && !collapsed && /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '0 var(--space-3) 6px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, g.label), g.items.map(it => /*#__PURE__*/React.createElement(SideItem, {
    key: it.id,
    item: it,
    active: it.id === active,
    collapsed: collapsed,
    onNavigate: onNavigate
  }))))), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, footer));
}
function SideItem({
  item,
  active,
  collapsed,
  onNavigate
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    title: collapsed ? item.label : undefined,
    onClick: e => {
      e.preventDefault();
      onNavigate && onNavigate(item.id);
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      height: 40,
      padding: collapsed ? '0' : '0 var(--space-3)',
      justifyContent: collapsed ? 'center' : 'flex-start',
      borderRadius: 'var(--radius-md)',
      textDecoration: 'none',
      background: active ? 'rgba(10,132,255,.12)' : hover ? 'var(--surface-hover)' : 'transparent',
      color: active ? 'var(--text-primary)' : hover ? 'var(--text-secondary)' : 'var(--text-muted)',
      fontSize: 'var(--text-sm)',
      fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
      transition: 'all var(--dur-fast) var(--ease-standard)'
    }
  }, active && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 9,
      bottom: 9,
      width: 2,
      borderRadius: 2,
      background: 'var(--gradient-brand)'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: item.icon,
    size: 17,
    color: active ? 'var(--brand-accent)' : 'currentColor'
  }), !collapsed && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, item.label), !collapsed && item.count != null && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    size: "sm",
    tone: active ? 'brand' : 'neutral'
  }, item.count));
}
Object.assign(__ds_scope, { SidebarNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange,
  variant = 'underline',
  style
}) {
  const pill = variant === 'pill';
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: pill ? 4 : 'var(--space-2)',
      padding: pill ? 4 : 0,
      borderRadius: pill ? 'var(--radius-md)' : 0,
      background: pill ? 'var(--surface-inset)' : 'transparent',
      border: pill ? '1px solid var(--border-subtle)' : 'none',
      borderBottom: pill ? '1px solid var(--border-subtle)' : '1px solid var(--border-subtle)',
      ...style
    }
  }, items.map(it => {
    const on = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      role: "tab",
      "aria-selected": on,
      onClick: () => onChange && onChange(it.id),
      style: {
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 7,
        height: pill ? 32 : 40,
        padding: pill ? '0 12px' : '0 4px',
        background: pill && on ? 'var(--surface-card)' : 'transparent',
        border: pill && on ? '1px solid var(--border-subtle)' : '1px solid transparent',
        borderRadius: pill ? 'var(--radius-sm)' : 0,
        cursor: 'pointer',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: on ? 'var(--text-primary)' : 'var(--text-muted)',
        transition: 'all var(--dur-fast) var(--ease-standard)'
      }
    }, it.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: it.icon,
      size: 15
    }), it.label, !pill && on && /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: -1,
        height: 2,
        background: 'var(--gradient-brand)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Screens.jsx
try { (() => {
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  CardHeader,
  Avatar,
  Divider,
  Icon,
  Table,
  StatCard,
  SkillMeter,
  Input,
  Textarea,
  Select,
  Checkbox,
  Switch,
  Tabs,
  Breadcrumbs,
  Pagination,
  Alert,
  EmptyState,
  Modal,
  ProgressBar,
  Tooltip
} = window.MohamedWeliJamaDesignSystem_8944ce;
function Topbar({
  title,
  crumbs,
  onNew,
  onToggleTheme,
  theme,
  onToggleSidebar
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      height: 68,
      flex: '0 0 auto',
      padding: '0 var(--space-7)',
      background: 'var(--surface-raised)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "panel-left",
    label: "Toggle sidebar",
    variant: "ghost",
    onClick: onToggleSidebar
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, title), crumbs && /*#__PURE__*/React.createElement(Breadcrumbs, {
    items: crumbs
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Search\u2026",
    containerStyle: {
      width: 220
    }
  }), /*#__PURE__*/React.createElement(Tooltip, {
    label: "Toggle theme"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: theme === 'dark' ? 'sun' : 'moon',
    label: "Theme",
    variant: "ghost",
    onClick: onToggleTheme
  })), /*#__PURE__*/React.createElement(Tooltip, {
    label: "3 unread"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "bell",
    label: "Notifications",
    variant: "ghost"
  })), onNew && /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "plus",
    onClick: onNew
  }, "New project"), /*#__PURE__*/React.createElement(Divider, {
    orientation: "vertical",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement(Avatar, {
    name: "Mohamed Weli Jama",
    size: "sm",
    status: "online"
  }));
}
function Dashboard({
  onGo
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Profile views",
    value: "12,480",
    delta: "+12.4%",
    icon: "eye",
    footnote: "vs. last 30 days"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Projects published",
    value: "14",
    delta: "+2",
    icon: "folder-git-2",
    footnote: "2 drafts pending"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "New messages",
    value: "3",
    delta: "-8%",
    deltaTone: "danger",
    icon: "mail",
    footnote: "oldest 2 days"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Uptime",
    value: "99.9%",
    icon: "activity",
    footnote: "all deployed apps"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5fr 1fr',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Views by week",
    subtitle: "Last 12 weeks",
    action: /*#__PURE__*/React.createElement(Tabs, {
      variant: "pill",
      value: "12w",
      onChange: () => {},
      items: [{
        id: '4w',
        label: '4w'
      }, {
        id: '12w',
        label: '12w'
      }, {
        id: '1y',
        label: '1y'
      }]
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 8,
      height: 180,
      padding: 'var(--space-4) 0 0'
    }
  }, [38, 44, 41, 58, 52, 64, 60, 72, 68, 84, 79, 96].map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      display: 'grid',
      gap: 6,
      justifyItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: h * 1.6,
      borderRadius: '6px 6px 2px 2px',
      background: i === 11 ? 'var(--gradient-brand)' : 'linear-gradient(180deg,rgba(10,132,255,.45),rgba(10,132,255,.06))',
      border: '1px solid var(--border-brand)',
      boxShadow: i === 11 ? 'var(--glow-accent)' : 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 9,
      color: 'var(--text-faint)'
    }
  }, "W", i + 1))))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Top technologies",
    subtitle: "By project count"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, window.AD.technologies.slice(0, 4).map(t => /*#__PURE__*/React.createElement(ProgressBar, {
    key: t.id,
    label: t.name,
    value: t.level,
    showValue: true
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-5) var(--space-5) var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Recent messages",
    subtitle: "3 unread",
    style: {
      marginBottom: 0
    },
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      iconRight: "arrow-right",
      onClick: () => onGo('messages')
    }, "Inbox")
  })), /*#__PURE__*/React.createElement("div", null, window.AD.messages.slice(0, 3).map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: m.id,
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center',
      padding: 'var(--space-4) var(--space-5)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: m.name,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 2,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, m.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, m.subject)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)'
    }
  }, m.time), m.unread && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--brand-primary)'
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)',
      alignContent: 'start'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "2 projects still in draft",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => onGo('projects')
    }, "Review drafts")
  }, "Draft projects are hidden from the public gallery."), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Quick actions"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "folder-plus",
    onClick: () => onGo('projects')
  }, "Add project"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "file-plus"
  }, "Write post"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "layers",
    onClick: () => onGo('technologies')
  }, "Add technology"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "upload"
  }, "Upload r\xE9sum\xE9"))))));
}
function Projects({
  onEdit,
  onNew
}) {
  const [sort, setSort] = React.useState('updated');
  const [filter, setFilter] = React.useState('all');
  const [page, setPage] = React.useState(1);
  const rows = window.AD.projects.filter(p => filter === 'all' || p.status.toLowerCase() === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    variant: "pill",
    value: filter,
    onChange: setFilter,
    items: [{
      id: 'all',
      label: 'All'
    }, {
      id: 'published',
      label: 'Published'
    }, {
      id: 'draft',
      label: 'Drafts'
    }, {
      id: 'archived',
      label: 'Archived'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    options: ['Sort: last updated', 'Sort: most viewed', 'Sort: A–Z'],
    containerStyle: {
      width: 190
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    icon: "download"
  }, "Export CSV"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "plus",
    onClick: onNew
  }, "New project")), rows.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "filter-x",
    title: "No projects in this state",
    description: "Switch the filter or create a new project.",
    action: /*#__PURE__*/React.createElement(Button, {
      icon: "plus",
      onClick: onNew
    }, "New project")
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Table, {
    sort: sort,
    onSort: setSort,
    rows: rows,
    columns: [{
      key: 'title',
      label: 'Project',
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 'var(--space-3)'
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 34,
          height: 34,
          borderRadius: 'var(--radius-sm)',
          background: 'var(--surface-inset)',
          border: '1px solid var(--border-subtle)',
          display: 'grid',
          placeItems: 'center'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "image",
        size: 14,
        color: "var(--text-faint)"
      })), /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'grid',
          gap: 2
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 6,
          color: 'var(--text-primary)',
          fontWeight: 'var(--weight-semibold)'
        }
      }, r.title, r.featured && /*#__PURE__*/React.createElement(Badge, {
        size: "sm",
        tone: "brand",
        icon: "star"
      }, "Featured")), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-2xs)',
          color: 'var(--text-faint)'
        }
      }, "/", r.slug)))
    }, {
      key: 'stack',
      label: 'Stack',
      render: r => /*#__PURE__*/React.createElement(Tag, {
        size: "sm"
      }, r.stack)
    }, {
      key: 'status',
      label: 'Status',
      render: r => /*#__PURE__*/React.createElement(Badge, {
        size: "sm",
        dot: true,
        tone: r.status === 'Published' ? 'success' : r.status === 'Draft' ? 'warning' : 'neutral'
      }, r.status)
    }, {
      key: 'views',
      label: 'Views',
      align: 'right',
      sortable: true
    }, {
      key: 'updated',
      label: 'Updated',
      sortable: true
    }, {
      key: 'a',
      label: '',
      align: 'right',
      width: 108,
      render: r => /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 4,
          justifyContent: 'flex-end'
        }
      }, /*#__PURE__*/React.createElement(IconButton, {
        size: "sm",
        variant: "ghost",
        icon: "external-link",
        label: "Preview"
      }), /*#__PURE__*/React.createElement(IconButton, {
        size: "sm",
        variant: "ghost",
        icon: "pencil",
        label: "Edit",
        onClick: () => onEdit(r)
      }), /*#__PURE__*/React.createElement(IconButton, {
        size: "sm",
        variant: "ghost",
        icon: "trash-2",
        label: "Delete",
        onClick: () => onEdit(r, 'delete')
      }))
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, "SHOWING ", rows.length, " OF 14"), /*#__PURE__*/React.createElement(Pagination, {
    page: page,
    pages: 3,
    onChange: setPage
  }))));
}
function ProjectEditor({
  project,
  onBack,
  onSave
}) {
  const [tab, setTab] = React.useState('content');
  const [featured, setFeatured] = React.useState(!!(project && project.featured));
  const [live, setLive] = React.useState(!project || project.status === 'Published');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow-left",
    onClick: onBack
  }, "Back to projects"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "eye"
  }, "Preview"), /*#__PURE__*/React.createElement(Button, {
    icon: "check",
    onClick: onSave
  }, "Save changes")), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      id: 'content',
      label: 'Content',
      icon: 'file-text'
    }, {
      id: 'media',
      label: 'Media',
      icon: 'image'
    }, {
      id: 'meta',
      label: 'SEO & meta',
      icon: 'search'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 'var(--space-5)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, tab === 'content' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Project title",
    defaultValue: project ? project.title : '',
    placeholder: "e.g. Somtel Self-Care"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Slug",
    icon: "link",
    defaultValue: project ? project.slug : '',
    hint: "Lowercase, hyphen-separated."
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Summary",
    rows: 3,
    defaultValue: project ? 'Airtime top-up, data bundles and billing history for 400k subscribers.' : ''
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "The problem",
    rows: 4,
    placeholder: "What was broken before this existed?"
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "The approach",
    rows: 4,
    placeholder: "How did you replace it?"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Client",
    defaultValue: project ? 'Somtel' : ''
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Duration",
    defaultValue: project ? '7 months' : ''
  }))), tab === 'media' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "upload-cloud",
    title: "Drop project screenshots here",
    description: "PNG or WebP, 1600px wide minimum. First image becomes the gallery thumbnail.",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "folder-open"
    }, "Browse files")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 'var(--space-3)'
    }
  }, [0, 1, 2, 3].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      aspectRatio: '4/3',
      borderRadius: 'var(--radius-md)',
      border: '1px dashed var(--border-strong)',
      background: 'var(--surface-inset)',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  }))))), tab === 'meta' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Meta title",
    defaultValue: project ? project.title + ' — Case study' : '',
    suffix: "58/60"
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Meta description",
    rows: 3,
    defaultValue: "Airtime and data self-service for 400k Somtel subscribers, built on Laravel and Vue."
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Canonical URL",
    icon: "link",
    defaultValue: project ? 'https://weli.dev/work/' + project.slug : ''
  }), /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Indexing"
  }, "Published projects are added to the sitemap within an hour."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Publishing"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Status",
    options: ['Published', 'Draft', 'Archived']
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Visible on public gallery",
    checked: live,
    onChange: setLive
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Feature on homepage",
    description: "Only one project can be featured.",
    checked: featured,
    onChange: setFeatured
  }), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    fullWidth: true,
    icon: "trash-2"
  }, "Delete project"))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Technologies",
    subtitle: "Shown as tags on the case study"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6,
      marginBottom: 'var(--space-4)'
    }
  }, ['Laravel', 'Vue', 'MySQL', 'Redis'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    size: "sm",
    onRemove: () => {}
  }, t))), /*#__PURE__*/React.createElement(Select, {
    size: "sm",
    options: ['Add technology…', 'React', 'Next.js', 'Docker', 'Tailwind CSS']
  })))));
}
function Technologies({
  onNew
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Filter technologies\u2026",
    containerStyle: {
      width: 260
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "plus",
    onClick: onNew
  }, "Add technology")), /*#__PURE__*/React.createElement(Table, {
    rows: window.AD.technologies,
    columns: [{
      key: 'name',
      label: 'Technology',
      sortable: true,
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: 'var(--font-mono)',
          color: 'var(--text-primary)',
          fontWeight: 'var(--weight-medium)'
        }
      }, r.name)
    }, {
      key: 'category',
      label: 'Category',
      render: r => /*#__PURE__*/React.createElement(Badge, {
        size: "sm",
        tone: "neutral"
      }, r.category)
    }, {
      key: 'projects',
      label: 'Projects',
      align: 'right',
      sortable: true
    }, {
      key: 'level',
      label: 'Proficiency',
      width: 220,
      render: r => /*#__PURE__*/React.createElement(ProgressBar, {
        value: r.level,
        size: "sm"
      })
    }, {
      key: 'a',
      label: '',
      align: 'right',
      width: 76,
      render: () => /*#__PURE__*/React.createElement("div", {
        style: {
          display: 'flex',
          gap: 4,
          justifyContent: 'flex-end'
        }
      }, /*#__PURE__*/React.createElement(IconButton, {
        size: "sm",
        variant: "ghost",
        icon: "pencil",
        label: "Edit"
      }), /*#__PURE__*/React.createElement(IconButton, {
        size: "sm",
        variant: "ghost",
        icon: "trash-2",
        label: "Delete"
      }))
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-4)'
    }
  }, window.AD.technologies.slice(0, 3).map(t => /*#__PURE__*/React.createElement(SkillMeter, {
    key: t.id,
    name: t.name,
    level: t.level,
    icon: "box",
    note: t.projects + ' projects'
  }))));
}
function Messages() {
  const [sel, setSel] = React.useState(window.AD.messages[0]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '340px 1fr',
      gap: 'var(--space-5)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    size: "sm",
    icon: "search",
    placeholder: "Search messages\u2026"
  })), window.AD.messages.map(m => {
    const on = sel && sel.id === m.id;
    return /*#__PURE__*/React.createElement("button", {
      key: m.id,
      onClick: () => setSel(m),
      style: {
        display: 'grid',
        gap: 5,
        width: '100%',
        textAlign: 'left',
        cursor: 'pointer',
        padding: 'var(--space-4)',
        border: 'none',
        borderBottom: '1px solid var(--border-subtle)',
        borderLeft: on ? '2px solid var(--brand-primary)' : '2px solid transparent',
        background: on ? 'rgba(10,132,255,.08)' : 'transparent',
        fontFamily: 'var(--font-body)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: m.name,
      size: "xs"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-semibold)',
        color: 'var(--text-primary)'
      }
    }, m.name), m.unread && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 7,
        height: 7,
        borderRadius: '50%',
        background: 'var(--brand-primary)'
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-xs)',
        color: 'var(--text-secondary)',
        fontWeight: 'var(--weight-medium)'
      }
    }, m.subject), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-xs)',
        color: 'var(--text-muted)',
        display: 'block',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, m.preview), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        color: 'var(--text-faint)'
      }
    }, m.time));
  })), sel ? /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-4)',
      marginBottom: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: sel.name,
    size: "lg"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 4,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, sel.subject), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, sel.name, " \xB7 ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)'
    }
  }, sel.email)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    size: "sm",
    tone: "brand"
  }, sel.tag), /*#__PURE__*/React.createElement(Badge, {
    size: "sm"
  }, sel.time))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "archive",
    label: "Archive",
    variant: "ghost"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "star",
    label: "Star",
    variant: "ghost"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "trash-2",
    label: "Delete",
    variant: "ghost"
  }))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-secondary)',
      margin: 'var(--space-5) 0'
    }
  }, sel.preview, " Let me know what a realistic timeline looks like and what you would need from us to get started. Happy to jump on a call this week."), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      marginTop: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Textarea, {
    label: "Reply",
    rows: 4,
    placeholder: "Write your reply\u2026"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "paperclip"
  }, "Attach"), /*#__PURE__*/React.createElement(Button, {
    iconRight: "send"
  }, "Send reply")))) : /*#__PURE__*/React.createElement(EmptyState, {
    icon: "mail-open",
    title: "No message selected",
    description: "Pick a message from the list."
  }));
}
function Settings() {
  const [dark, setDark] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-5)',
      alignItems: 'start',
      maxWidth: 980
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Profile",
    subtitle: "Shown across the public site"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Mohamed Weli Jama",
    size: "lg",
    ring: true
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    icon: "upload"
  }, "Replace photo")), /*#__PURE__*/React.createElement(Input, {
    label: "Display name",
    defaultValue: "Mohamed Weli Jama"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Role",
    defaultValue: "Software & Web Developer"
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Mission statement",
    rows: 2,
    defaultValue: "My mission is to digitalize our Country.",
    hint: "Rendered in tracked uppercase in the footer."
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Location",
    icon: "map-pin",
    defaultValue: "Hargeisa, Somaliland"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Appearance"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Dark theme by default",
    checked: dark,
    onChange: setDark
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Respect visitor system preference",
    checked: true,
    description: "Overrides the default above."
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Accent",
    options: ['Primary — #0A84FF', 'Accent — #00C2FF', 'Deep blue — #0066FF']
  }))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement(CardHeader, {
    title: "Danger zone"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "danger",
    title: "Irreversible actions"
  }, "Removing all content cannot be undone."), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    icon: "trash-2"
  }, "Delete all content")))));
}
function Login({
  onLogin
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'grid',
      placeItems: 'center',
      position: 'relative',
      overflow: 'hidden',
      padding: 'var(--space-7)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--gradient-hero-glow)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)',
      backgroundSize: '28px 28px',
      maskImage: 'radial-gradient(60% 50% at 50% 40%,#000,transparent)',
      WebkitMaskImage: 'radial-gradient(60% 50% at 50% 40%,#000,transparent)'
    }
  }), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: 420,
      boxShadow: 'var(--shadow-xl), var(--glow-accent)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)',
      justifyItems: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-lockup.png",
    alt: "",
    style: {
      width: 64,
      height: 64,
      objectFit: 'cover',
      objectPosition: 'center 22%',
      borderRadius: 'var(--radius-md)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, "Portfolio admin"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, "Private dashboard. Authorised access only.")), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onLogin();
    },
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      width: '100%',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    icon: "mail",
    defaultValue: "mohamed@weli.dev"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    icon: "lock",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Keep me signed in",
    checked: true
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 'var(--text-xs)'
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right"
  }, "Sign in")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--text-faint)'
    }
  }, "</> MY MISSION IS TO DIGITALIZE OUR COUNTRY"))));
}
Object.assign(window, {
  Topbar,
  Dashboard,
  Projects,
  ProjectEditor,
  Technologies,
  Messages,
  Settings,
  Login
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/data.js
try { (() => {
window.AD = {
  groups: [{
    label: 'Overview',
    items: [{
      id: 'dashboard',
      label: 'Dashboard',
      icon: 'layout-dashboard'
    }, {
      id: 'analytics',
      label: 'Analytics',
      icon: 'bar-chart-3'
    }]
  }, {
    label: 'Content',
    items: [{
      id: 'projects',
      label: 'Projects',
      icon: 'folder-git-2',
      count: 14
    }, {
      id: 'technologies',
      label: 'Technologies',
      icon: 'layers',
      count: 24
    }, {
      id: 'services',
      label: 'Services',
      icon: 'briefcase',
      count: 4
    }, {
      id: 'blog',
      label: 'Blog posts',
      icon: 'file-text',
      count: 8
    }, {
      id: 'experience',
      label: 'Experience',
      icon: 'milestone',
      count: 3
    }]
  }, {
    label: 'Inbox',
    items: [{
      id: 'messages',
      label: 'Messages',
      icon: 'mail',
      count: 3
    }]
  }, {
    label: 'System',
    items: [{
      id: 'settings',
      label: 'Settings',
      icon: 'settings'
    }]
  }],
  projects: [{
    id: 1,
    title: 'Somtel Self-Care',
    slug: 'somtel-self-care',
    stack: 'Laravel',
    status: 'Published',
    featured: true,
    views: '4,120',
    updated: '2 hours ago'
  }, {
    id: 2,
    title: 'Hargeisa Clinic Booking',
    slug: 'hargeisa-clinic-booking',
    stack: 'React',
    status: 'Published',
    views: '2,884',
    updated: 'Yesterday'
  }, {
    id: 3,
    title: 'School Fee Portal',
    slug: 'school-fee-portal',
    stack: 'Next.js',
    status: 'Published',
    views: '1,902',
    updated: '3 days ago'
  }, {
    id: 4,
    title: 'Berbera Freight Tracker',
    slug: 'berbera-freight-tracker',
    stack: 'Laravel',
    status: 'Published',
    views: '1,340',
    updated: '1 week ago'
  }, {
    id: 5,
    title: 'Agri Market Prices',
    slug: 'agri-market-prices',
    stack: 'PHP',
    status: 'Draft',
    views: '—',
    updated: '2 weeks ago'
  }, {
    id: 6,
    title: 'Municipal Permit Desk',
    slug: 'municipal-permit-desk',
    stack: 'Laravel',
    status: 'Archived',
    views: '812',
    updated: '3 months ago'
  }],
  technologies: [{
    id: 1,
    name: 'Laravel',
    category: 'Backend',
    projects: 7,
    level: 92
  }, {
    id: 2,
    name: 'React',
    category: 'Frontend',
    projects: 5,
    level: 88
  }, {
    id: 3,
    name: 'PostgreSQL',
    category: 'Database',
    projects: 4,
    level: 85
  }, {
    id: 4,
    name: 'Tailwind CSS',
    category: 'Frontend',
    projects: 9,
    level: 90
  }, {
    id: 5,
    name: 'Docker',
    category: 'DevOps',
    projects: 3,
    level: 68
  }],
  messages: [{
    id: 1,
    name: 'Amina Yusuf',
    email: 'amina@alnuur.edu.so',
    subject: 'Fee portal — second phase',
    preview: 'We would like to add parent logins before the new term starts in October. Can you scope…',
    time: '12 min ago',
    unread: true,
    tag: 'Web application development'
  }, {
    id: 2,
    name: 'Khadar Ali',
    email: 'k.ali@berberaport.so',
    subject: 'Freight tracker maintenance',
    preview: 'The container export is timing out on large date ranges. Are you available this week to…',
    time: '2 hours ago',
    unread: true,
    tag: 'Maintenance & handover'
  }, {
    id: 3,
    name: 'Sagal Ibrahim',
    email: 'sagal@clinicnet.so',
    subject: 'Booking system — SMS reminders',
    preview: 'Patients keep missing appointments. Could we add an SMS reminder 24 hours before…',
    time: 'Yesterday',
    unread: true,
    tag: 'Web application development'
  }, {
    id: 4,
    name: 'Mustafe Hassan',
    email: 'mustafe@tabaarak.com',
    subject: 'Contract work — Q4',
    preview: 'We have three client sites lined up and would like to bring you on as a subcontractor…',
    time: '2 days ago',
    unread: false,
    tag: 'Responsive front-end work'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/data.js", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/Sections.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  IconButton,
  Badge,
  Tag,
  Card,
  CardHeader,
  Avatar,
  Divider,
  SectionHeading,
  Tabs,
  ProjectCard,
  Timeline,
  SkillMeter,
  StatCard,
  Icon,
  Input,
  Textarea,
  Select,
  Alert,
  EmptyState
} = window.MohamedWeliJamaDesignSystem_8944ce;
const LOGO = '../../assets/logo-lockup.png';
const wrap = {
  maxWidth: 'var(--layout-max)',
  margin: '0 auto',
  padding: '0 var(--layout-gutter)'
};
const section = {
  padding: 'var(--section-y) 0'
};
function Hero({
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      padding: 'var(--space-13) 0 var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--gradient-hero-glow)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)',
      backgroundSize: '28px 28px',
      maskImage: 'radial-gradient(70% 60% at 50% 30%,#000,transparent)',
      WebkitMaskImage: 'radial-gradient(70% 60% at 50% 30%,#000,transparent)',
      opacity: .7,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      position: 'relative',
      display: 'grid',
      gridTemplateColumns: '1.15fr .85fr',
      gap: 'var(--space-11)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)',
      justifyItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "Available for new projects"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-hero)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-tight)',
      lineHeight: 1.02,
      margin: 0
    }
  }, "Software that", /*#__PURE__*/React.createElement("br", null), "actually ships \u2014", ' ', /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--gradient-text)',
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent'
    }
  }, "and gets used.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-lg)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)',
      maxWidth: 540
    }
  }, "I'm Mohamed Weli Jama, a software and web developer in Hargeisa. I build practical digital products for telecom, health, education and government teams."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    iconRight: "arrow-up-right",
    onClick: () => onNavigate('work')
  }, "View selected work"), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    variant: "secondary",
    icon: "download"
  }, "Download r\xE9sum\xE9")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)',
      marginTop: 'var(--space-4)'
    }
  }, [['14', 'Products shipped'], ['4', 'Years building'], ['9', 'Clients served']].map(([n, l]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      display: 'grid',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-2xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-tight)'
    }
  }, n), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      justifyItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: LOGO,
    alt: "Mohamed Weli Jama",
    style: {
      width: '100%',
      maxWidth: 340,
      aspectRatio: '1',
      objectFit: 'contain',
      borderRadius: 'var(--radius-2xl)',
      border: '1px solid var(--border-subtle)',
      background: '#000',
      boxShadow: 'var(--shadow-xl), var(--glow-accent)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--track-wide)',
      color: 'var(--brand-accent)'
    }
  }, "</> MY MISSION IS TO DIGITALIZE OUR COUNTRY"))));
}
function About() {
  return /*#__PURE__*/React.createElement("section", {
    id: "about",
    style: {
      ...section,
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '.9fr 1.1fr',
      gap: 'var(--space-11)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "01 / About",
    title: "A developer who finishes things"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)'
    }
  }, "I started writing PHP for a telecom internal tool in 2021 and never stopped. Most of my work since then has been the same shape: a process someone runs on paper, in a spreadsheet or over WhatsApp, turned into something auditable that a small team can maintain."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)'
    }
  }, "I care about two things more than anything else: that the thing gets shipped, and that it still works six months after I hand it over."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, ['github', 'linkedin', 'twitter', 'mail'].map(i => /*#__PURE__*/React.createElement(IconButton, {
    key: i,
    icon: i,
    label: i
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    glow: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Mohamed Weli Jama",
    size: "xl",
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)'
    }
  }, "Mohamed Weli Jama"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--brand-accent)'
    }
  }, "Software & Web Developer"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, "Hargeisa, Somaliland \xB7 GMT+3"))), /*#__PURE__*/React.createElement(Divider, {
    style: {
      margin: 'var(--space-5) 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, [['Focus', 'Web platforms'], ['Stack', 'Laravel · React'], ['Languages', 'Somali · English · Arabic'], ['Working style', 'Remote or on-site']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'grid',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, v))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, window.PF.achievements.slice(0, 4).map(a => /*#__PURE__*/React.createElement(Card, {
    key: a.title,
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: a.icon,
    size: 18,
    color: "var(--brand-accent)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, a.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)'
    }
  }, a.meta)))))))));
}
function Skills() {
  return /*#__PURE__*/React.createElement("section", {
    style: section
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "02 / Skills",
    title: "Technologies I work in daily",
    description: "Percentages reflect how much of my shipped work leans on each \u2014 not a self-assessment."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-4)'
    }
  }, window.PF.skills.map(s => /*#__PURE__*/React.createElement(SkillMeter, _extends({
    key: s.name
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-2)'
    }
  }, ['TypeScript', 'Livewire', 'Alpine.js', 'Inertia', 'Redis', 'Nginx', 'Git', 'Figma', 'Vite', 'REST', 'Stripe', 'Twilio', 'Chart.js', 'Linux'].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))));
}
function Work({
  onOpen
}) {
  const [filter, setFilter] = React.useState('all');
  const all = window.PF.projects;
  const list = filter === 'all' ? all : all.filter(p => p.status.toLowerCase() === filter);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      ...section,
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "03 / Projects",
    title: "Selected work",
    description: "Six of fourteen shipped products. Each one replaced a manual process.",
    action: /*#__PURE__*/React.createElement(Tabs, {
      variant: "pill",
      value: filter,
      onChange: setFilter,
      items: [{
        id: 'all',
        label: 'All'
      }, {
        id: 'live',
        label: 'Live'
      }, {
        id: 'archived',
        label: 'Archived'
      }]
    })
  }), list.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "filter-x",
    title: "Nothing under that filter",
    description: "Try \u201CAll\u201D to see every project."
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-6)'
    }
  }, list.map(p => /*#__PURE__*/React.createElement(ProjectCard, _extends({
    key: p.id
  }, p, {
    onOpen: () => onOpen(p)
  }))))));
}
function Services() {
  return /*#__PURE__*/React.createElement("section", {
    style: section
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-9)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    align: "center",
    eyebrow: "04 / Services",
    title: "How I can help",
    description: "Four ways clients usually bring me in. Fixed scope where possible, retainer where it isn't."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr)',
      gap: 'var(--space-5)'
    }
  }, window.PF.services.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: s.title,
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      flex: '0 0 auto',
      display: 'grid',
      placeItems: 'center',
      borderRadius: 'var(--radius-md)',
      background: 'rgba(10,132,255,.10)',
      border: '1px solid var(--border-brand)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 20,
    color: "var(--brand-accent)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, s.title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)'
    }
  }, "0", i + 1)), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)'
    }
  }, s.body))))))));
}
function Experience() {
  const [tab, setTab] = React.useState('experience');
  return /*#__PURE__*/React.createElement("section", {
    style: {
      ...section,
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '.8fr 1.2fr',
      gap: 'var(--space-11)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)',
      position: 'sticky',
      top: 'calc(var(--nav-h) + 32px)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "05 / Path",
    title: "Experience & education"
  }), /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      id: 'experience',
      label: 'Experience',
      icon: 'briefcase'
    }, {
      id: 'education',
      label: 'Education',
      icon: 'graduation-cap'
    }]
  })), /*#__PURE__*/React.createElement(Timeline, {
    items: tab === 'experience' ? window.PF.experience : window.PF.education
  })));
}
function Blog() {
  return /*#__PURE__*/React.createElement("section", {
    style: section
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "06 / Writing",
    title: "Notes from the work",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      iconRight: "arrow-right"
    }, "All posts")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-5)'
    }
  }, window.PF.posts.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.title,
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "brand",
    size: "sm"
  }, p.tag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)'
    }
  }, p.read)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1.3
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)'
    }
  }, p.excerpt), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)'
    }
  }, p.date)))))));
}
function Contact() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      ...section,
      background: 'var(--bg-subtle)',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-11)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "07 / Contact",
    title: "Let's build something useful",
    description: "Tell me what process you're trying to replace. I reply to every message within two working days."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, [['mail', 'mohamed@weli.dev'], ['phone', '+252 63 000 0000'], ['map-pin', 'Hargeisa, Somaliland'], ['clock', 'Mon–Sat, 09:00–18:00 GMT+3']].map(([i, v]) => /*#__PURE__*/React.createElement("div", {
    key: v,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i,
    size: 16,
    color: "var(--brand-accent)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, v))))), /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, sent ? /*#__PURE__*/React.createElement(Alert, {
    tone: "success",
    title: "Message sent"
  }, "Thanks \u2014 I'll be in touch within two working days.") : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Name",
    icon: "user",
    placeholder: "Your name",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    icon: "mail",
    placeholder: "you@company.com",
    required: true
  })), /*#__PURE__*/React.createElement(Select, {
    label: "What do you need?",
    options: ['Web application development', 'Responsive front-end work', 'Digitalizing a manual process', 'Maintenance & handover']
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Project details",
    rows: 5,
    placeholder: "What are you replacing, and by when?"
  }), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "lg",
    fullWidth: true,
    iconRight: "send"
  }, "Send message")))));
}
function CaseStudy({
  project,
  onBack
}) {
  const [tab, setTab] = React.useState('overview');
  const p = project;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...wrap,
      padding: 'var(--space-9) var(--layout-gutter) var(--space-12)',
      display: 'grid',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow-left",
    onClick: onBack,
    style: {
      justifySelf: 'start'
    }
  }, "Back to work"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, p.status), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)'
    }
  }, p.year)), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-4xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-tight)',
      lineHeight: 1.05,
      margin: 0
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-lg)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)',
      maxWidth: 680
    }
  }, p.summary), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: '21/9',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      background: 'var(--surface-card)',
      backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)',
      backgroundSize: '28px 28px',
      display: 'grid',
      placeItems: 'center',
      gap: 8,
      color: 'var(--text-faint)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "image",
    size: 26
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-eyebrow)'
    }
  }, "PROJECT SCREENSHOT")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 300px',
      gap: 'var(--space-9)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    items: [{
      id: 'overview',
      label: 'Overview'
    }, {
      id: 'stack',
      label: 'Stack',
      icon: 'layers'
    }, {
      id: 'results',
      label: 'Results',
      icon: 'trending-up'
    }]
  }), tab === 'overview' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-6)',
      maxWidth: 680
    }
  }, /*#__PURE__*/React.createElement(Block, {
    title: "The problem",
    body: p.problem || 'A manual process that could not scale with the number of people relying on it.'
  }), /*#__PURE__*/React.createElement(Block, {
    title: "The approach",
    body: p.approach || 'Mapped the existing process with the people who run it, then replaced the highest-volume journeys first.'
  })), tab === 'stack' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)',
      maxWidth: 680
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement(Card, {
    key: t,
    padding: "sm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "box",
    size: 17,
    color: "var(--brand-accent)"
  }), /*#__PURE__*/React.createElement("strong", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-sm)'
    }
  }, t))))), tab === 'results' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 'var(--space-4)'
    }
  }, (p.outcome || [{
    k: 'Outcome',
    v: '—'
  }]).map(o => /*#__PURE__*/React.createElement(StatCard, {
    key: o.k,
    label: o.k,
    value: o.v
  })))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-4)'
    }
  }, [['Client', p.client || '—'], ['Role', p.role || '—'], ['Duration', p.duration || '—'], ['Year', p.year]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'grid',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: 'var(--track-wide)',
      textTransform: 'uppercase',
      color: 'var(--text-faint)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, v))), /*#__PURE__*/React.createElement(Divider, null), /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    iconRight: "external-link"
  }, "Visit live site"), /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    variant: "secondary",
    icon: "github"
  }, "Source")))));
}
function Block({
  title,
  body
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-xl)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--track-snug)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-muted)'
    }
  }, body));
}
Object.assign(window, {
  Hero,
  About,
  Skills,
  Work,
  Services,
  Experience,
  Blog,
  Contact,
  CaseStudy
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/Sections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portfolio/data.js
try { (() => {
window.PF = {
  nav: [{
    id: 'home',
    label: 'Home'
  }, {
    id: 'about',
    label: 'About'
  }, {
    id: 'work',
    label: 'Work'
  }, {
    id: 'services',
    label: 'Services'
  }, {
    id: 'blog',
    label: 'Blog'
  }, {
    id: 'contact',
    label: 'Contact'
  }],
  projects: [{
    id: 'somtel',
    title: 'Somtel Self-Care',
    year: '2025',
    status: 'Live',
    featured: true,
    summary: 'Airtime top-up, data bundles and billing history for 400k subscribers.',
    tags: ['Laravel', 'Vue', 'MySQL', 'Redis'],
    role: 'Full-stack developer',
    client: 'Somtel',
    duration: '7 months',
    problem: 'Subscribers had to visit a branch or call support to top up or check a balance. Support handled 3,000+ repetitive calls a week.',
    approach: 'Built a self-service portal on top of the existing billing API, starting with the three journeys that generated the most calls: top-up, bundle purchase and balance history.',
    outcome: [{
      k: 'Support calls',
      v: '-62%'
    }, {
      k: 'Monthly active users',
      v: '118k'
    }, {
      k: 'Avg. top-up time',
      v: '41s'
    }]
  }, {
    id: 'clinic',
    title: 'Hargeisa Clinic Booking',
    year: '2024',
    status: 'Live',
    summary: 'Appointment booking and patient records for a six-clinic network.',
    tags: ['React', 'Node', 'PostgreSQL'],
    role: 'Lead developer',
    client: 'Private network',
    duration: '5 months'
  }, {
    id: 'fees',
    title: 'School Fee Portal',
    year: '2024',
    status: 'Live',
    summary: 'Fee tracking and mobile-money reconciliation for 2,400 students.',
    tags: ['Next.js', 'Prisma', 'Stripe'],
    role: 'Solo developer',
    client: 'Al-Nuur Schools',
    duration: '3 months'
  }, {
    id: 'logistics',
    title: 'Berbera Freight Tracker',
    year: '2023',
    status: 'Live',
    summary: 'Container tracking dashboard for a port logistics operator.',
    tags: ['Laravel', 'Livewire', 'MySQL']
  }, {
    id: 'agri',
    title: 'Agri Market Prices',
    year: '2023',
    status: 'Live',
    summary: 'Daily crop price index collected by SMS from 40 markets.',
    tags: ['PHP', 'Twilio', 'Chart.js']
  }, {
    id: 'gov',
    title: 'Municipal Permit Desk',
    year: '2022',
    status: 'Archived',
    summary: 'Digital permit applications replacing a paper intake process.',
    tags: ['Laravel', 'Bootstrap']
  }],
  skills: [{
    name: 'Laravel / PHP',
    level: 92,
    icon: 'server',
    note: 'Primary backend stack'
  }, {
    name: 'React / Next.js',
    level: 88,
    icon: 'code-2',
    note: 'Most client front-ends'
  }, {
    name: 'PostgreSQL / MySQL',
    level: 85,
    icon: 'database'
  }, {
    name: 'Tailwind CSS',
    level: 90,
    icon: 'palette'
  }, {
    name: 'Node / Express',
    level: 76,
    icon: 'terminal'
  }, {
    name: 'Docker & CI',
    level: 68,
    icon: 'container',
    note: 'Deploying to VPS and Fly.io'
  }],
  services: [{
    icon: 'globe',
    title: 'Web application development',
    body: 'End-to-end builds: data model, API, interface, deployment. Laravel or Next.js depending on the team that will maintain it.'
  }, {
    icon: 'smartphone',
    title: 'Responsive front-end work',
    body: 'Turning designs into accessible, fast interfaces that hold up on the 3G connections most of my users are on.'
  }, {
    icon: 'workflow',
    title: 'Digitalizing manual processes',
    body: 'Paper intake, spreadsheet tracking, WhatsApp order books — mapped, then replaced with something auditable.'
  }, {
    icon: 'wrench',
    title: 'Maintenance & handover',
    body: 'Taking over an existing codebase, documenting it, and leaving it in a state your own team can run.'
  }],
  experience: [{
    title: 'Software Developer',
    org: 'Freelance · Hargeisa',
    period: '2023 — Present',
    current: true,
    description: 'Building web platforms for telecom, health, education and logistics clients across Somaliland.',
    tags: ['Laravel', 'React', 'PostgreSQL']
  }, {
    title: 'Web Developer',
    org: 'Tabaarak ICT Solutions',
    period: '2022 — 2023',
    description: 'Delivered client sites and internal tools; owned the front-end of three government-facing portals.',
    tags: ['PHP', 'Bootstrap', 'MySQL']
  }, {
    title: 'Junior Developer (Intern)',
    org: 'Somtel',
    period: '2021 — 2022',
    description: 'Maintained internal reporting tools and wrote the first version of the billing API client.',
    tags: ['PHP', 'jQuery']
  }],
  education: [{
    title: 'BSc Computer Science',
    org: 'University of Hargeisa',
    period: '2019 — 2023',
    icon: 'graduation-cap',
    description: 'Graduated with distinction. Final project: an SMS-based agricultural price index, later shipped as a public site.'
  }, {
    title: 'Meta Front-End Developer Certificate',
    org: 'Coursera',
    period: '2023',
    icon: 'award'
  }],
  achievements: [{
    icon: 'trophy',
    title: 'National Innovation Challenge — 2nd place',
    meta: '2024 · Ministry of Telecommunication'
  }, {
    icon: 'users',
    title: 'Mentored 30+ junior developers',
    meta: '2022 — Present · local dev community'
  }, {
    icon: 'git-merge',
    title: 'Open-source contributor',
    meta: 'Laravel ecosystem packages'
  }, {
    icon: 'presentation',
    title: 'Speaker — Hargeisa Tech Meetup',
    meta: '2023, 2024, 2025'
  }],
  posts: [{
    title: 'Shipping software on a 3G budget',
    date: '12 Aug 2026',
    read: '6 min',
    tag: 'Performance',
    excerpt: 'Every kilobyte is a decision when your median user is on a shared 3G connection. Here is the budget I hold myself to.'
  }, {
    title: 'Why I still reach for Laravel first',
    date: '28 Jul 2026',
    read: '8 min',
    tag: 'Backend',
    excerpt: 'Not because it is fashionable — because the teams I hand projects to can actually maintain it.'
  }, {
    title: 'Digitalizing a paper permit desk',
    date: '03 Jul 2026',
    read: '11 min',
    tag: 'Case study',
    excerpt: 'What I learned mapping a municipal process before writing a single line of code.'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portfolio/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ProjectCard = __ds_scope.ProjectCard;

__ds_ns.SkillMeter = __ds_scope.SkillMeter;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Timeline = __ds_scope.Timeline;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.LABEL = __ds_scope.LABEL;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Breadcrumbs = __ds_scope.Breadcrumbs;

__ds_ns.Pagination = __ds_scope.Pagination;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Navbar = __ds_scope.Navbar;

__ds_ns.SidebarNav = __ds_scope.SidebarNav;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
