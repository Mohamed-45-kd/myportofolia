/** Determinate progress track, and the loading Skeleton shimmer. */
export interface ProgressBarProps {
  /** 0–100. */
  value?: number;
  label?: React.ReactNode;
  /** Shows the monospace percentage on the right. */
  showValue?: boolean;
  size?: 'sm' | 'md' | 'lg';
  tone?: 'brand' | 'success' | 'warning' | 'danger';
  style?: React.CSSProperties;
}
export function ProgressBar(props: ProgressBarProps): JSX.Element;

export interface SkeletonProps {
  width?: number | string;
  height?: number | string;
  radius?: string;
  style?: React.CSSProperties;
}
export function Skeleton(props: SkeletonProps): JSX.Element;
