One-line: dialogs for admin create/edit and destructive confirms.

```jsx
<Modal open={open} title="Delete project" description="This cannot be undone."
  footer={<><Button variant="ghost" onClick={close}>Cancel</Button><Button variant="danger">Delete</Button></>}
  onClose={close} />
```

Confirm buttons go right; cancel is always `ghost`.
