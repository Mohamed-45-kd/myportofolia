One-line: skill levels, upload progress, dashboard goals; Skeleton for loading placeholders.

```jsx
<ProgressBar label="React & Next.js" value={92} showValue />
<Skeleton width={180} height={18} />
```
