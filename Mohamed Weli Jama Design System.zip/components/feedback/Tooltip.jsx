import React from 'react';

export function Tooltip({ label, children, placement = 'top', style }) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: { bottom: '100%', left: '50%', transform: 'translate(-50%,-8px)' },
    bottom: { top: '100%', left: '50%', transform: 'translate(-50%,8px)' },
    left: { right: '100%', top: '50%', transform: 'translate(-8px,-50%)' },
    right: { left: '100%', top: '50%', transform: 'translate(8px,-50%)' },
  }[placement];
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}
      onFocus={() => setShow(true)} onBlur={() => setShow(false)}>
      {children}
      {show && (
        <span role="tooltip" style={{
          position: 'absolute', zIndex: 60, ...pos, whiteSpace: 'nowrap',
          padding: '6px 10px', borderRadius: 'var(--radius-sm)',
          background: 'var(--ink-800)', border: '1px solid var(--border-strong)',
          boxShadow: 'var(--shadow-md)', color: 'var(--text-primary)',
          fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: '.02em',
          pointerEvents: 'none', ...style,
        }}>{label}</span>
      )}
    </span>
  );
}
