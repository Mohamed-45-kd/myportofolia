/** Dashed placeholder for empty lists, filtered-out galleries and zero-message inboxes. */
export interface EmptyStateProps {
  /** Lucide icon name. Default "inbox". */
  icon?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  action?: React.ReactNode;
  /** Tighter padding for in-card use. */
  compact?: boolean;
  style?: React.CSSProperties;
}
export function EmptyState(props: EmptyStateProps): JSX.Element;
