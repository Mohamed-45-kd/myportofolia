import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function EmptyState({ icon = 'inbox', title, description, action, compact = false, style }) {
  return (
    <div style={{
      display: 'grid', justifyItems: 'center', gap: 'var(--space-3)', textAlign: 'center',
      padding: compact ? 'var(--space-7)' : 'var(--space-11) var(--space-7)',
      border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-lg)',
      background: 'var(--surface-inset)', ...style,
    }}>
      <span style={{
        width: 46, height: 46, display: 'grid', placeItems: 'center', borderRadius: 'var(--radius-md)',
        background: 'rgba(10,132,255,.10)', border: '1px solid var(--border-brand)',
      }}>
        <Icon name={icon} size={21} color="var(--brand-accent)" />
      </span>
      <strong style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)' }}>{title}</strong>
      {description && <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', maxWidth: 360, lineHeight: 'var(--leading-normal)' }}>{description}</p>}
      {action && <div style={{ marginTop: 'var(--space-2)' }}>{action}</div>}
    </div>
  );
}
