/** Monospace hover label. Wrap the trigger as `children`. */
export interface TooltipProps {
  label: React.ReactNode;
  children?: React.ReactNode;
  placement?: 'top' | 'bottom' | 'left' | 'right';
  style?: React.CSSProperties;
}
export function Tooltip(props: TooltipProps): JSX.Element;
