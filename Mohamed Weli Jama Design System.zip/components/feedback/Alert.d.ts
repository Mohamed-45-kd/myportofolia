/**
 * Inline banner (Alert) and floating notification (Toast).
 * @startingPoint section="Feedback" subtitle="Alerts, toasts, empty states and progress" viewport="700x300"
 */
export interface AlertProps {
  tone?: 'info' | 'success' | 'warning' | 'danger';
  title?: React.ReactNode;
  children?: React.ReactNode;
  onDismiss?: () => void;
  /** Trailing control row, usually a ghost Button. */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export function Alert(props: AlertProps): JSX.Element;

export interface ToastProps {
  tone?: 'info' | 'success' | 'warning' | 'danger';
  title?: React.ReactNode;
  children?: React.ReactNode;
  onDismiss?: () => void;
  style?: React.CSSProperties;
}
export function Toast(props: ToastProps): JSX.Element;
