One-line: Alert sits in the flow (form errors, admin notices); Toast floats bottom-right after an action.

```jsx
<Alert tone="warning" title="Unsaved changes">Publish to make them live.</Alert>
<Toast tone="success" title="Project saved" onDismiss={close} />
```

Toast carries a 3px tone bar on its left edge; Alert tints its whole surface.
