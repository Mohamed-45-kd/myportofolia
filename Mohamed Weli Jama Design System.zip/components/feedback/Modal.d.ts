/** Centred dialog on a blurred overlay. Closes on Escape and backdrop click. */
export interface ModalProps {
  open?: boolean;
  title?: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  /** Right-aligned action row on the inset footer bar. */
  footer?: React.ReactNode;
  onClose?: () => void;
  /** Max width in px. Default 520. */
  width?: number;
  style?: React.CSSProperties;
}
export function Modal(props: ModalProps): JSX.Element | null;
