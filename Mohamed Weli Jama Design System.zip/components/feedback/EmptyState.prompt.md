One-line: what a list shows when it has nothing — always with a next action.

```jsx
<EmptyState icon="folder-plus" title="No projects yet" description="Add your first case study." action={<Button icon="plus">New project</Button>} />
```
