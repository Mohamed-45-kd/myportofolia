One-line: short monospace hover label for icon-only controls and chart points.

```jsx
<Tooltip label="Open in GitHub"><IconButton icon="github" label="GitHub" /></Tooltip>
```
