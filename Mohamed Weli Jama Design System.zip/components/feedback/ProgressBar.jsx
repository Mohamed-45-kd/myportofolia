import React from 'react';

export function ProgressBar({ value = 0, label, showValue = false, size = 'md', tone = 'brand', style }) {
  const h = size === 'sm' ? 4 : size === 'lg' ? 10 : 6;
  const fill = tone === 'brand' ? 'var(--gradient-brand)' : `var(--${tone}-500)`;
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div style={{ display: 'grid', gap: 'var(--space-2)', ...style }}>
      {(label || showValue) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 'var(--space-4)' }}>
          {label && <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', fontWeight: 'var(--weight-medium)' }}>{label}</span>}
          {showValue && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--brand-accent)' }}>{pct}%</span>}
        </div>
      )}
      <div role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}
        style={{ height: h, borderRadius: 'var(--radius-pill)', background: 'var(--surface-inset)', border: '1px solid var(--border-subtle)', overflow: 'hidden' }}>
        <div style={{ width: pct + '%', height: '100%', background: fill, borderRadius: 'var(--radius-pill)', boxShadow: 'var(--glow-accent)', transition: 'width var(--dur-slower) var(--ease-out)' }} />
      </div>
    </div>
  );
}

export function Skeleton({ width = '100%', height = 14, radius = 'var(--radius-sm)', style }) {
  return (
    <span style={{
      display: 'block', width, height, borderRadius: radius,
      background: 'linear-gradient(90deg,var(--surface-inset) 0%,var(--surface-hover) 50%,var(--surface-inset) 100%)',
      backgroundSize: '200% 100%', animation: 'mwj-shimmer 1.4s var(--ease-standard) infinite', ...style,
    }}>
      <style>{'@keyframes mwj-shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}'}</style>
    </span>
  );
}
