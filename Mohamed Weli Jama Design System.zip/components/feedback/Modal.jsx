import React from 'react';
import { IconButton } from '../core/IconButton.jsx';

export function Modal({ open, title, description, children, footer, onClose, width = 520, style }) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape' && onClose) onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div role="dialog" aria-modal="true" aria-label={typeof title === 'string' ? title : undefined}
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 90, display: 'grid', placeItems: 'center',
        padding: 'var(--space-6)', background: 'var(--surface-overlay)',
        backdropFilter: 'var(--blur-md)', WebkitBackdropFilter: 'var(--blur-md)',
        animation: 'mwj-fade var(--dur-base) var(--ease-out)',
      }}>
      <style>{'@keyframes mwj-fade{from{opacity:0}to{opacity:1}}@keyframes mwj-rise{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}'}</style>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: '100%', maxWidth: width, background: 'var(--surface-card)',
        border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-xl)',
        boxShadow: 'var(--shadow-xl), var(--inset-hairline-strong)', overflow: 'hidden',
        animation: 'mwj-rise var(--dur-slow) var(--ease-out)', ...style,
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-4)', padding: 'var(--space-6) var(--space-6) var(--space-4)' }}>
          <div style={{ display: 'grid', gap: 5, flex: 1 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>{title}</h3>
            {description && <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', lineHeight: 'var(--leading-normal)' }}>{description}</p>}
          </div>
          {onClose && <IconButton icon="x" label="Close" variant="ghost" size="sm" onClick={onClose} />}
        </div>
        {children && <div style={{ padding: '0 var(--space-6) var(--space-6)' }}>{children}</div>}
        {footer && (
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-3)', padding: 'var(--space-5) var(--space-6)', background: 'var(--surface-inset)', borderTop: '1px solid var(--border-subtle)' }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}
