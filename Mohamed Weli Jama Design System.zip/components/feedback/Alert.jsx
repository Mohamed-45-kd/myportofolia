import React from 'react';
import { Icon } from '../core/Icon.jsx';

const TONES = {
  info:    { fg: 'var(--info-500)',    bg: 'var(--info-surface)',    bd: 'rgba(0,194,255,.28)',   icon: 'info' },
  success: { fg: 'var(--success-500)', bg: 'var(--success-surface)', bd: 'rgba(34,211,154,.28)',  icon: 'check-circle-2' },
  warning: { fg: 'var(--warning-500)', bg: 'var(--warning-surface)', bd: 'rgba(255,176,32,.28)',  icon: 'alert-triangle' },
  danger:  { fg: 'var(--danger-500)',  bg: 'var(--danger-surface)',  bd: 'rgba(255,77,94,.28)',   icon: 'alert-octagon' },
};

export function Alert({ tone = 'info', title, children, onDismiss, action, style }) {
  const t = TONES[tone] || TONES.info;
  return (
    <div role={tone === 'danger' ? 'alert' : 'status'} style={{
      display: 'flex', gap: 'var(--space-3)', padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)', background: t.bg, border: `1px solid ${t.bd}`, ...style,
    }}>
      <span style={{ marginTop: 1 }}><Icon name={t.icon} size={18} color={t.fg} /></span>
      <div style={{ display: 'grid', gap: 4, flex: 1 }}>
        {title && <strong style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)', color: 'var(--text-primary)' }}>{title}</strong>}
        {children && <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', lineHeight: 'var(--leading-normal)' }}>{children}</div>}
        {action && <div style={{ marginTop: 6 }}>{action}</div>}
      </div>
      {onDismiss && (
        <button type="button" aria-label="Dismiss" onClick={onDismiss}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 0, height: 18 }}>
          <Icon name="x" size={16} />
        </button>
      )}
    </div>
  );
}

export function Toast({ tone = 'success', title, children, onDismiss, style }) {
  const t = TONES[tone] || TONES.success;
  return (
    <div role="status" style={{
      display: 'flex', gap: 'var(--space-3)', alignItems: 'flex-start',
      minWidth: 300, maxWidth: 420, padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)', background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-lg), var(--inset-hairline)',
      backdropFilter: 'var(--blur-sm)', ...style,
    }}>
      <span style={{ width: 3, alignSelf: 'stretch', borderRadius: 3, background: t.fg, flex: '0 0 auto' }} />
      <Icon name={t.icon} size={18} color={t.fg} />
      <div style={{ display: 'grid', gap: 2, flex: 1 }}>
        <strong style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)' }}>{title}</strong>
        {children && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{children}</span>}
      </div>
      {onDismiss && (
        <button type="button" aria-label="Dismiss" onClick={onDismiss} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-faint)', padding: 0 }}>
          <Icon name="x" size={15} />
        </button>
      )}
    </div>
  );
}
