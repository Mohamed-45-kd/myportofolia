One-line: the three boolean controls — Checkbox (multi), Radio (exclusive), Switch (immediate effect).

```jsx
<Checkbox label="Featured project" description="Pins to the top of the gallery" checked={on} onChange={setOn} />
<Switch label="Dark theme" checked={dark} onChange={setDark} />
```

Use Switch only when the change applies immediately; otherwise Checkbox.
