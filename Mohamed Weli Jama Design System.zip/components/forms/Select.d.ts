/** Native select styled to match Input. */
export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
  error?: string;
  /** Strings, or { value, label } objects. */
  options?: Array<string | { value: string; label: string }>;
  size?: 'sm' | 'md' | 'lg';
  containerStyle?: React.CSSProperties;
}
export function Select(props: SelectProps): JSX.Element;
