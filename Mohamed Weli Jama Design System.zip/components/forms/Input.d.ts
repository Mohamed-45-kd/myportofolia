/**
 * Text field on the inset surface with a brand focus ring.
 * @startingPoint section="Forms" subtitle="Inputs, selects, toggles and a contact form" viewport="700x320"
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Tracked-uppercase label above the field. */
  label?: string;
  /** Helper copy below the field. */
  hint?: string;
  /** Error message; replaces `hint` and turns the border red. */
  error?: string;
  /** Leading Lucide icon name. */
  icon?: string;
  /** Trailing monospace unit/affix. */
  suffix?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
  containerStyle?: React.CSSProperties;
}
export function Input(props: InputProps): JSX.Element;

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
  error?: string;
  rows?: number;
  containerStyle?: React.CSSProperties;
}
export function Textarea(props: TextareaProps): JSX.Element;
