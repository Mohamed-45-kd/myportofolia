One-line: single-choice dropdown matching Input's metrics.

```jsx
<Select label="Status" options={['Draft', 'Published', 'Archived']} />
```
