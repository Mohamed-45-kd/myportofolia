One-line: the text field for contact forms, admin CRUD and search.

```jsx
<Input label="Email" icon="mail" placeholder="you@company.com" hint="I reply within two days." />
<Textarea label="Message" rows={5} />
```

Labels are always uppercase + tracked. Errors set `error` (never colour the label).
