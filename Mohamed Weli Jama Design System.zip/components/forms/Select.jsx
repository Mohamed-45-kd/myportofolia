import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { LABEL } from './Input.jsx';

export function Select({ label, hint, error, options = [], size = 'md', id, style, containerStyle, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  const h = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  return (
    <div style={{ display: 'grid', gap: 'var(--space-2)', ...containerStyle }}>
      {label && <label htmlFor={uid} style={LABEL}>{label}</label>}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        <select id={uid} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            appearance: 'none', width: '100%', height: h, padding: '0 var(--space-9) 0 var(--space-4)',
            borderRadius: 'var(--radius-md)', background: 'var(--surface-inset)',
            border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
            boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
            color: 'var(--text-primary)', fontFamily: 'var(--font-body)', fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-base)',
            outline: 'none', cursor: 'pointer', transition: 'border-color var(--dur-base) var(--ease-standard)', ...style,
          }} {...rest}>
          {options.map((o) => {
            const v = typeof o === 'string' ? o : o.value;
            const l = typeof o === 'string' ? o : o.label;
            return <option key={v} value={v} style={{ background: 'var(--surface-card)' }}>{l}</option>;
          })}
        </select>
        <span style={{ position: 'absolute', right: 'var(--space-4)', pointerEvents: 'none', display: 'flex' }}>
          <Icon name="chevron-down" size={16} color="var(--text-muted)" />
        </span>
      </div>
      {(hint || error) && <span style={{ fontSize: 'var(--text-xs)', color: error ? 'var(--danger-500)' : 'var(--text-faint)' }}>{error || hint}</span>}
    </div>
  );
}
