import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Checkbox({ label, description, checked, onChange, disabled, id, style }) {
  const uid = id || React.useId();
  return (
    <label htmlFor={uid} style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'flex-start', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }}>
      <input id={uid} type="checkbox" checked={!!checked} disabled={disabled}
        onChange={(e) => onChange && onChange(e.target.checked, e)}
        style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: 18, height: 18, flex: '0 0 auto', marginTop: 2, borderRadius: 'var(--radius-xs)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: checked ? 'var(--gradient-brand)' : 'var(--surface-inset)',
        border: `1px solid ${checked ? 'transparent' : 'var(--border-strong)'}`,
        boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
        transition: 'all var(--dur-fast) var(--ease-standard)',
      }}>
        {checked && <Icon name="check" size={13} stroke={3} color="#fff" />}
      </span>
      <span style={{ display: 'grid', gap: 2 }}>
        <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-primary)' }}>{label}</span>
        {description && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{description}</span>}
      </span>
    </label>
  );
}

export function Radio({ label, description, checked, onChange, name, value, disabled, id, style }) {
  const uid = id || React.useId();
  return (
    <label htmlFor={uid} style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'flex-start', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }}>
      <input id={uid} type="radio" name={name} value={value} checked={!!checked} disabled={disabled}
        onChange={(e) => onChange && onChange(value, e)}
        style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: 18, height: 18, flex: '0 0 auto', marginTop: 2, borderRadius: '50%',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--surface-inset)',
        border: `1px solid ${checked ? 'var(--brand-primary)' : 'var(--border-strong)'}`,
        boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
        transition: 'all var(--dur-fast) var(--ease-standard)',
      }}>
        {checked && <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--gradient-brand)' }} />}
      </span>
      <span style={{ display: 'grid', gap: 2 }}>
        <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-primary)' }}>{label}</span>
        {description && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{description}</span>}
      </span>
    </label>
  );
}

export function Switch({ label, checked, onChange, disabled, size = 'md', style }) {
  const w = size === 'sm' ? 34 : 44, h = size === 'sm' ? 20 : 25, k = h - 6;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-3)', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .5 : 1, ...style }}>
      <input type="checkbox" checked={!!checked} disabled={disabled} role="switch"
        onChange={(e) => onChange && onChange(e.target.checked, e)}
        style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} />
      <span style={{
        width: w, height: h, borderRadius: 'var(--radius-pill)', flex: '0 0 auto', position: 'relative',
        background: checked ? 'var(--gradient-brand)' : 'var(--surface-inset)',
        border: `1px solid ${checked ? 'transparent' : 'var(--border-strong)'}`,
        boxShadow: checked ? 'var(--glow-brand)' : 'var(--inset-hairline)',
        transition: 'all var(--dur-base) var(--ease-standard)',
      }}>
        <span style={{
          position: 'absolute', top: 2, left: checked ? w - k - 4 : 2, width: k, height: k, borderRadius: '50%',
          background: checked ? '#fff' : 'var(--text-muted)',
          transition: 'left var(--dur-base) var(--ease-spring), background var(--dur-base) var(--ease-standard)',
        }} />
      </span>
      {label && <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{label}</span>}
    </label>
  );
}
