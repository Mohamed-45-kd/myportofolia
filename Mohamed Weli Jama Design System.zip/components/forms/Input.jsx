import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Input({ label, hint, error, icon, suffix, size = 'md', id, style, containerStyle, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  const h = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  return (
    <div style={{ display: 'grid', gap: 'var(--space-2)', ...containerStyle }}>
      {label && <label htmlFor={uid} style={LABEL}>{label}</label>}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 'var(--space-3)', height: h,
        padding: '0 var(--space-4)', borderRadius: 'var(--radius-md)',
        background: 'var(--surface-inset)',
        border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
        boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
        transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)',
      }}>
        {icon && <Icon name={icon} size={17} color={focus ? 'var(--brand-accent)' : 'var(--text-faint)'} />}
        <input id={uid}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          aria-invalid={!!error} aria-describedby={hint || error ? uid + '-d' : undefined}
          style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none', color: 'var(--text-primary)', fontFamily: 'var(--font-body)', fontSize: size === 'sm' ? 'var(--text-sm)' : 'var(--text-base)', ...style }}
          {...rest} />
        {suffix && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{suffix}</span>}
      </div>
      {(hint || error) && <span id={uid + '-d'} style={{ fontSize: 'var(--text-xs)', color: error ? 'var(--danger-500)' : 'var(--text-faint)' }}>{error || hint}</span>}
    </div>
  );
}

export const LABEL = {
  fontFamily: 'var(--font-body)', fontSize: 'var(--text-xs)', fontWeight: 'var(--weight-semibold)',
  letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-muted)',
};

export function Textarea({ label, hint, error, rows = 4, id, style, containerStyle, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const uid = id || React.useId();
  return (
    <div style={{ display: 'grid', gap: 'var(--space-2)', ...containerStyle }}>
      {label && <label htmlFor={uid} style={LABEL}>{label}</label>}
      <textarea id={uid} rows={rows}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} aria-invalid={!!error}
        style={{
          padding: 'var(--space-4)', borderRadius: 'var(--radius-md)', background: 'var(--surface-inset)',
          border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
          boxShadow: focus && !error ? '0 0 0 3px rgba(10,132,255,.18)' : 'var(--inset-hairline)',
          color: 'var(--text-primary)', fontFamily: 'var(--font-body)', fontSize: 'var(--text-base)',
          lineHeight: 'var(--leading-normal)', outline: 'none', resize: 'vertical',
          transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)', ...style,
        }} {...rest} />
      {(hint || error) && <span style={{ fontSize: 'var(--text-xs)', color: error ? 'var(--danger-500)' : 'var(--text-faint)' }}>{error || hint}</span>}
    </div>
  );
}
