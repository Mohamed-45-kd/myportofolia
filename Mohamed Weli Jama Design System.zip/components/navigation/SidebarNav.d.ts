/**
 * Admin dashboard sidebar: grouped items, mono group labels, 2px gradient active marker.
 * @startingPoint section="Navigation" subtitle="Grouped admin sidebar, collapsible" viewport="700x420"
 */
export interface SidebarItem { id: string; label: string; icon: string; count?: number; }
export interface SidebarGroup { label?: string; items: SidebarItem[]; }
export interface SidebarNavProps {
  groups?: SidebarGroup[];
  active?: string;
  onNavigate?: (id: string) => void;
  logoSrc?: string;
  /** Icon-only rail at 72px. */
  collapsed?: boolean;
  /** Pinned to the bottom — usually the account row. */
  footer?: React.ReactNode;
  style?: React.CSSProperties;
}
export function SidebarNav(props: SidebarNavProps): JSX.Element;
