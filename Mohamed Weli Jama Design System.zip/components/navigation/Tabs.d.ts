/** Section switcher. `underline` for page-level, `pill` for in-card. */
export interface TabItem { id: string; label: string; icon?: string; }
export interface TabsProps {
  items?: TabItem[];
  value?: string;
  onChange?: (id: string) => void;
  variant?: 'underline' | 'pill';
  style?: React.CSSProperties;
}
export function Tabs(props: TabsProps): JSX.Element;
