import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Logo } from '../core/Logo.jsx';
import { Badge } from '../core/Badge.jsx';

export function SidebarNav({ groups = [], active, onNavigate, logoSrc, collapsed = false, footer, style }) {
  return (
    <aside style={{
      width: collapsed ? 'var(--sidebar-w-collapsed)' : 'var(--sidebar-w)', flex: '0 0 auto',
      display: 'flex', flexDirection: 'column', gap: 'var(--space-6)',
      background: 'var(--surface-raised)', borderRight: '1px solid var(--border-subtle)',
      padding: 'var(--space-5) var(--space-4)', height: '100%', overflowY: 'auto',
      transition: 'width var(--dur-base) var(--ease-standard)', ...style,
    }}>
      <div style={{ padding: '0 var(--space-2)' }}>
        {collapsed ? <Logo variant="mark" size={32} src={logoSrc} /> : <Logo size={32} src={logoSrc} />}
      </div>
      <nav style={{ display: 'grid', gap: 'var(--space-6)' }}>
        {groups.map((g) => (
          <div key={g.label || 'g'} style={{ display: 'grid', gap: 4 }}>
            {g.label && !collapsed && (
              <span style={{ padding: '0 var(--space-3) 6px', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-eyebrow)', textTransform: 'uppercase', color: 'var(--text-faint)' }}>{g.label}</span>
            )}
            {g.items.map((it) => <SideItem key={it.id} item={it} active={it.id === active} collapsed={collapsed} onNavigate={onNavigate} />)}
          </div>
        ))}
      </nav>
      {footer && <div style={{ marginTop: 'auto' }}>{footer}</div>}
    </aside>
  );
}

function SideItem({ item, active, collapsed, onNavigate }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a href="#" title={collapsed ? item.label : undefined}
      onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(item.id); }}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative', display: 'flex', alignItems: 'center', gap: 'var(--space-3)',
        height: 40, padding: collapsed ? '0' : '0 var(--space-3)', justifyContent: collapsed ? 'center' : 'flex-start',
        borderRadius: 'var(--radius-md)', textDecoration: 'none',
        background: active ? 'rgba(10,132,255,.12)' : hover ? 'var(--surface-hover)' : 'transparent',
        color: active ? 'var(--text-primary)' : hover ? 'var(--text-secondary)' : 'var(--text-muted)',
        fontSize: 'var(--text-sm)', fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        transition: 'all var(--dur-fast) var(--ease-standard)',
      }}>
      {active && <span style={{ position: 'absolute', left: 0, top: 9, bottom: 9, width: 2, borderRadius: 2, background: 'var(--gradient-brand)' }} />}
      <Icon name={item.icon} size={17} color={active ? 'var(--brand-accent)' : 'currentColor'} />
      {!collapsed && <span style={{ flex: 1 }}>{item.label}</span>}
      {!collapsed && item.count != null && <Badge size="sm" tone={active ? 'brand' : 'neutral'}>{item.count}</Badge>}
    </a>
  );
}
