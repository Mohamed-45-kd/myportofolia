One-line: the public portfolio header — logo left, links right, one CTA.

```jsx
<Navbar items={[{id:'home',label:'Home'},{id:'work',label:'Work'}]} active="home" cta={{label:'Hire me'}} onToggleTheme={toggle} />
```

The active link is marked by a 2px gradient underline, never a filled pill.
