One-line: switches views in place — case-study sections, dashboard panels.

```jsx
<Tabs items={[{id:'overview',label:'Overview'},{id:'stack',label:'Stack',icon:'layers'}]} value={tab} onChange={setTab} />
```
