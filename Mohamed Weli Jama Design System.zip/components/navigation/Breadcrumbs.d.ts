/** Breadcrumb trail and numeric pagination. */
export interface Crumb { id?: string; label: string; }
export interface BreadcrumbsProps {
  items?: Crumb[];
  onNavigate?: (id?: string) => void;
  style?: React.CSSProperties;
}
export function Breadcrumbs(props: BreadcrumbsProps): JSX.Element;

export interface PaginationProps {
  page?: number;
  pages?: number;
  onChange?: (page: number) => void;
  style?: React.CSSProperties;
}
export function Pagination(props: PaginationProps): JSX.Element;
