import React from 'react';
import { Logo } from '../core/Logo.jsx';
import { Button } from '../core/Button.jsx';
import { IconButton } from '../core/IconButton.jsx';

export function Navbar({ items = [], active, onNavigate, logoSrc, cta, onToggleTheme, theme = 'dark', style }) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 40, height: 'var(--nav-h)',
      display: 'flex', alignItems: 'center',
      background: scrolled ? 'color-mix(in srgb, var(--bg-base) 78%, transparent)' : 'transparent',
      backdropFilter: scrolled ? 'var(--blur-md)' : 'none',
      WebkitBackdropFilter: scrolled ? 'var(--blur-md)' : 'none',
      borderBottom: `1px solid ${scrolled ? 'var(--border-subtle)' : 'transparent'}`,
      transition: 'all var(--dur-base) var(--ease-standard)', ...style,
    }}>
      <div style={{ width: '100%', maxWidth: 'var(--layout-max)', margin: '0 auto', padding: '0 var(--layout-gutter)', display: 'flex', alignItems: 'center', gap: 'var(--space-7)' }}>
        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(items[0] && items[0].id); }} style={{ textDecoration: 'none' }}>
          <Logo size={34} src={logoSrc} />
        </a>
        <nav style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-1)', marginLeft: 'auto' }}>
          {items.map((it) => {
            const on = it.id === active;
            return (
              <a key={it.id} href={it.href || '#'} onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(it.id); }}
                style={{
                  position: 'relative', padding: '8px 12px', borderRadius: 'var(--radius-sm)',
                  fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-medium)',
                  color: on ? 'var(--text-primary)' : 'var(--text-muted)', textDecoration: 'none',
                  transition: 'color var(--dur-fast) var(--ease-standard)',
                }}>
                {it.label}
                {on && <span style={{ position: 'absolute', left: 12, right: 12, bottom: 2, height: 2, borderRadius: 2, background: 'var(--gradient-brand)', boxShadow: 'var(--glow-accent)' }} />}
              </a>
            );
          })}
        </nav>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
          {onToggleTheme && <IconButton icon={theme === 'dark' ? 'sun' : 'moon'} label="Toggle theme" variant="ghost" onClick={onToggleTheme} />}
          {cta && <Button size="sm" iconRight="arrow-up-right" onClick={cta.onClick}>{cta.label}</Button>}
        </div>
      </div>
    </header>
  );
}
