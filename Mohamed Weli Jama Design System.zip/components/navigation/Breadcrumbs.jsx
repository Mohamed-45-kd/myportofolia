import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Breadcrumbs({ items = [], onNavigate, style }) {
  return (
    <nav aria-label="Breadcrumb" style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)', flexWrap: 'wrap', ...style }}>
      {items.map((it, i) => {
        const last = i === items.length - 1;
        return (
          <React.Fragment key={it.id || it.label}>
            {last ? (
              <span aria-current="page" style={{ fontSize: 'var(--text-sm)', color: 'var(--text-primary)', fontWeight: 'var(--weight-medium)' }}>{it.label}</span>
            ) : (
              <a href="#" onClick={(e) => { e.preventDefault(); onNavigate && onNavigate(it.id); }}
                style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', textDecoration: 'none' }}>{it.label}</a>
            )}
            {!last && <Icon name="chevron-right" size={14} color="var(--text-faint)" />}
          </React.Fragment>
        );
      })}
    </nav>
  );
}

export function Pagination({ page = 1, pages = 1, onChange, style }) {
  const nums = [];
  for (let i = 1; i <= pages; i++) nums.push(i);
  const shown = pages <= 7 ? nums : nums.filter((n) => n === 1 || n === pages || Math.abs(n - page) <= 1);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, ...style }}>
      <PagBtn disabled={page <= 1} onClick={() => onChange && onChange(page - 1)}><Icon name="chevron-left" size={15} /></PagBtn>
      {shown.map((n, i) => (
        <React.Fragment key={n}>
          {i > 0 && n - shown[i - 1] > 1 && <span style={{ color: 'var(--text-faint)', fontSize: 'var(--text-sm)', padding: '0 2px' }}>…</span>}
          <PagBtn active={n === page} onClick={() => onChange && onChange(n)}>{n}</PagBtn>
        </React.Fragment>
      ))}
      <PagBtn disabled={page >= pages} onClick={() => onChange && onChange(page + 1)}><Icon name="chevron-right" size={15} /></PagBtn>
    </div>
  );
}

function PagBtn({ children, active, disabled, onClick }) {
  return (
    <button type="button" disabled={disabled} onClick={onClick}
      style={{
        minWidth: 34, height: 34, padding: '0 8px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 'var(--radius-sm)', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? .4 : 1,
        background: active ? 'rgba(10,132,255,.14)' : 'var(--surface-card)',
        border: `1px solid ${active ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
        color: active ? 'var(--brand-accent)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)',
        transition: 'all var(--dur-fast) var(--ease-standard)',
      }}>{children}</button>
  );
}
