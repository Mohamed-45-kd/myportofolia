/**
 * Public site header: sticky, transparent at rest, blurred + hairlined once scrolled.
 * @startingPoint section="Navigation" subtitle="Sticky public header with theme toggle" viewport="700x140"
 */
export interface NavItem { id: string; label: string; href?: string; }
export interface NavbarProps {
  items?: NavItem[];
  /** id of the current item. */
  active?: string;
  onNavigate?: (id: string) => void;
  /** Path to assets/logo-lockup.png relative to the page. */
  logoSrc?: string;
  cta?: { label: string; onClick?: () => void };
  onToggleTheme?: () => void;
  theme?: 'dark' | 'light';
  style?: React.CSSProperties;
}
export function Navbar(props: NavbarProps): JSX.Element;
