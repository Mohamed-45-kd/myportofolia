One-line: closes every public page; the mission line lives here.

```jsx
<Footer note="Building practical digital solutions from Somalia." socials={[{icon:'github',label:'GitHub'}]} columns={[…]} />
```
