import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Tabs({ items = [], value, onChange, variant = 'underline', style }) {
  const pill = variant === 'pill';
  return (
    <div role="tablist" style={{
      display: 'inline-flex', alignItems: 'center', gap: pill ? 4 : 'var(--space-2)',
      padding: pill ? 4 : 0, borderRadius: pill ? 'var(--radius-md)' : 0,
      background: pill ? 'var(--surface-inset)' : 'transparent',
      border: pill ? '1px solid var(--border-subtle)' : 'none',
      borderBottom: pill ? '1px solid var(--border-subtle)' : '1px solid var(--border-subtle)',
      ...style,
    }}>
      {items.map((it) => {
        const on = it.id === value;
        return (
          <button key={it.id} role="tab" aria-selected={on} onClick={() => onChange && onChange(it.id)}
            style={{
              position: 'relative', display: 'inline-flex', alignItems: 'center', gap: 7,
              height: pill ? 32 : 40, padding: pill ? '0 12px' : '0 4px',
              background: pill && on ? 'var(--surface-card)' : 'transparent',
              border: pill && on ? '1px solid var(--border-subtle)' : '1px solid transparent',
              borderRadius: pill ? 'var(--radius-sm)' : 0, cursor: 'pointer',
              fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)',
              fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
              color: on ? 'var(--text-primary)' : 'var(--text-muted)',
              transition: 'all var(--dur-fast) var(--ease-standard)',
            }}>
            {it.icon && <Icon name={it.icon} size={15} />}
            {it.label}
            {!pill && on && <span style={{ position: 'absolute', left: 0, right: 0, bottom: -1, height: 2, background: 'var(--gradient-brand)' }} />}
          </button>
        );
      })}
    </div>
  );
}
