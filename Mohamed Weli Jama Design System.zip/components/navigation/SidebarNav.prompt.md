One-line: the admin shell's left navigation.

```jsx
<SidebarNav groups={[{label:'Content',items:[{id:'projects',label:'Projects',icon:'folder-git-2',count:12}]}]} active="projects" />
```
