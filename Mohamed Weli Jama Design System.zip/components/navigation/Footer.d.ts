/** Site footer: mission lockup + link columns + social rail. */
export interface FooterColumn { title: string; links: Array<{ label: string; href?: string }>; }
export interface FooterProps {
  columns?: FooterColumn[];
  socials?: Array<{ icon: string; label: string; href?: string }>;
  logoSrc?: string;
  note?: string;
  style?: React.CSSProperties;
}
export function Footer(props: FooterProps): JSX.Element;
