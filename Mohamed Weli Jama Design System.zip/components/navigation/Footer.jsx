import React from 'react';
import { Logo } from '../core/Logo.jsx';
import { Icon } from '../core/Icon.jsx';

export function Footer({ columns = [], socials = [], logoSrc, note, style }) {
  return (
    <footer style={{ borderTop: '1px solid var(--border-subtle)', background: 'var(--bg-subtle)', ...style }}>
      <div style={{ maxWidth: 'var(--layout-max)', margin: '0 auto', padding: 'var(--space-11) var(--layout-gutter) var(--space-7)', display: 'grid', gap: 'var(--space-9)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr repeat(auto-fit,minmax(140px,1fr))', gap: 'var(--space-9)' }}>
          <div style={{ display: 'grid', gap: 'var(--space-4)', alignContent: 'start' }}>
            <Logo size={38} src={logoSrc} showMission />
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', maxWidth: 300, lineHeight: 'var(--leading-relaxed)' }}>{note}</p>
            <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
              {socials.map((s) => (
                <a key={s.icon} href={s.href || '#'} aria-label={s.label}
                  style={{ width: 36, height: 36, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-subtle)', background: 'var(--surface-card)', color: 'var(--text-muted)' }}>
                  <Icon name={s.icon} size={16} />
                </a>
              ))}
            </div>
          </div>
          {columns.map((c) => (
            <div key={c.title} style={{ display: 'grid', gap: 'var(--space-3)', alignContent: 'start' }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-eyebrow)', textTransform: 'uppercase', color: 'var(--text-faint)' }}>{c.title}</span>
              {c.links.map((l) => (
                <a key={l.label} href={l.href || '#'} style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', textDecoration: 'none' }}>{l.label}</a>
              ))}
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-4)', justifyContent: 'space-between', paddingTop: 'var(--space-6)', borderTop: '1px solid var(--border-subtle)' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>© {new Date().getFullYear()} Mohamed Weli Jama</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>Built and maintained by hand</span>
        </div>
      </div>
    </footer>
  );
}
