One-line: breadcrumb trail (admin CRUD, case studies) and numeric pagination (blog, project gallery).

```jsx
<Breadcrumbs items={[{id:'admin',label:'Dashboard'},{label:'Edit project'}]} />
<Pagination page={2} pages={9} onChange={setPage} />
```
