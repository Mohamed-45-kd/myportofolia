import React from 'react';

export function Divider({ label, orientation = 'horizontal', gradient = false, style }) {
  const line = gradient
    ? 'linear-gradient(90deg,rgba(30,41,59,0) 0%,var(--border-strong) 50%,rgba(30,41,59,0) 100%)'
    : 'var(--border-subtle)';
  if (orientation === 'vertical') {
    return <span aria-hidden="true" style={{ width: 1, alignSelf: 'stretch', background: line, flex: '0 0 auto', ...style }} />;
  }
  if (!label) return <hr style={{ border: 'none', height: 1, background: line, margin: 0, ...style }} />;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', ...style }}>
      <span style={{ flex: 1, height: 1, background: line }} />
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-eyebrow)', color: 'var(--text-faint)', textTransform: 'uppercase' }}>{label}</span>
      <span style={{ flex: 1, height: 1, background: line }} />
    </div>
  );
}
