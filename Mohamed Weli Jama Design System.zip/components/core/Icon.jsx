import React from 'react';

/* Lucide (CDN) is the brand icon set — 1.75px stroke, 24px grid, round caps.
   Loads the UMD build once, then hydrates any <i data-lucide> placeholder. */
let lucidePromise = null;
function ensureLucide() {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.lucide) return Promise.resolve();
  if (lucidePromise) return lucidePromise;
  lucidePromise = new Promise((res) => {
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/lucide@0.454.0/dist/umd/lucide.min.js';
    s.onload = res; s.onerror = res;
    document.head.appendChild(s);
  });
  return lucidePromise;
}

export function Icon({ name, size = 20, stroke = 1.75, color = 'currentColor', style, ...rest }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    let dead = false;
    ensureLucide().then(() => {
      if (dead || !ref.current || !window.lucide) return;
      ref.current.innerHTML = '';
      const el = document.createElement('i');
      el.setAttribute('data-lucide', name);
      ref.current.appendChild(el);
      window.lucide.createIcons({
        icons: window.lucide.icons,
        nameAttr: 'data-lucide',
        attrs: { width: size, height: size, 'stroke-width': stroke, stroke: color, 'stroke-linecap': 'round', 'stroke-linejoin': 'round' },
        root: ref.current,
      });
    });
    return () => { dead = true; };
  }, [name, size, stroke, color]);
  return (
    <span
      ref={ref}
      aria-hidden="true"
      style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: size, height: size, flex: '0 0 auto', color, ...style }}
      {...rest}
    />
  );
}
