One-line: renders a Lucide glyph at the brand stroke weight (1.75px); use for every icon rather than inline SVG.

```jsx
<Icon name="arrow-up-right" size={18} />
```

Notes: `name` is any Lucide name in kebab-case. Loads Lucide from CDN once per page. Inherits `currentColor` so it tints with its parent — pass `color="var(--brand-accent)"` to override.
