/** Brand lockup. `src` must point at assets/logo-lockup.png relative to the consuming page. */
export interface LogoProps {
  src?: string;
  /** lockup = mark + wordmark, mark = monogram only, wordmark = live type only. */
  variant?: 'lockup' | 'mark' | 'wordmark';
  /** Mark box in px. Default 36. */
  size?: number;
  /** Swap the tagline line for the mission statement. */
  showMission?: boolean;
  style?: React.CSSProperties;
}
export function Logo(props: LogoProps): JSX.Element;
