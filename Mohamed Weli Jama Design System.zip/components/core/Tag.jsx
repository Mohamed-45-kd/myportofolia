import React from 'react';
import { Icon } from './Icon.jsx';

export function Tag({ children, active = false, onRemove, onClick, size = 'md', style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick;
  const sm = size === 'sm';
  return (
    <span
      onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        height: sm ? 24 : 30, padding: sm ? '0 9px' : '0 12px',
        borderRadius: 'var(--radius-sm)',
        background: active ? 'rgba(10,132,255,.12)' : hover && interactive ? 'var(--surface-hover)' : 'var(--surface-inset)',
        border: `1px solid ${active ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
        color: active ? 'var(--brand-accent)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-mono)', fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)',
        fontWeight: 'var(--weight-medium)', letterSpacing: '0.01em',
        cursor: interactive ? 'pointer' : 'default', whiteSpace: 'nowrap',
        transition: 'all var(--dur-base) var(--ease-standard)', ...style,
      }}
      {...rest}
    >
      {children}
      {onRemove && (
        <button type="button" aria-label="Remove" onClick={(e) => { e.stopPropagation(); onRemove(e); }}
          style={{ display: 'inline-flex', background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'inherit', opacity: .65 }}>
          <Icon name="x" size={12} />
        </button>
      )}
    </span>
  );
}
