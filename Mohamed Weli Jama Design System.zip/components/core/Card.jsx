import React from 'react';

export function Card({ children, padding = 'md', interactive = false, glow = false, as = 'div', style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const pad = { none: 0, sm: 'var(--space-4)', md: 'var(--space-6)', lg: 'var(--space-7)' }[padding] ?? 'var(--space-6)';
  const Tag = as;
  return (
    <Tag
      onMouseEnter={interactive ? () => setHover(true) : undefined}
      onMouseLeave={interactive ? () => setHover(false) : undefined}
      style={{
        position: 'relative', background: 'var(--surface-card)',
        border: `1px solid ${hover ? 'var(--border-brand)' : 'var(--border-subtle)'}`,
        borderRadius: 'var(--radius-lg)', padding: pad,
        boxShadow: hover ? 'var(--shadow-lg), var(--inset-hairline-strong)' : `var(--shadow-sm), var(--inset-hairline)${glow ? ', var(--glow-accent)' : ''}`,
        transform: hover ? 'translateY(-3px)' : 'none',
        transition: 'transform var(--dur-base) var(--ease-out), box-shadow var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
        cursor: interactive ? 'pointer' : undefined, textDecoration: 'none', color: 'inherit',
        ...style,
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}

export function CardHeader({ title, subtitle, action, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 'var(--space-4)', marginBottom: 'var(--space-4)', ...style }}>
      <div style={{ display: 'grid', gap: 4 }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--track-snug)' }}>{title}</h3>
        {subtitle && <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
