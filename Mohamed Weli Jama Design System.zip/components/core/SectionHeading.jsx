import React from 'react';

export function SectionHeading({ eyebrow, title, description, align = 'left', action, style }) {
  const center = align === 'center';
  return (
    <div style={{ display: 'grid', gap: 'var(--space-3)', textAlign: center ? 'center' : 'left', justifyItems: center ? 'center' : 'start', maxWidth: center ? 720 : undefined, margin: center ? '0 auto' : undefined, ...style }}>
      {eyebrow && (
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', letterSpacing: 'var(--track-eyebrow)', textTransform: 'uppercase', color: 'var(--brand-accent)' }}>
          <span style={{ width: 22, height: 1, background: 'var(--brand-primary)' }} />{eyebrow}
        </span>
      )}
      <div style={{ display: 'flex', width: '100%', alignItems: 'flex-end', justifyContent: 'space-between', gap: 'var(--space-6)' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-tight)', lineHeight: 1.1, margin: 0 }}>{title}</h2>
        {action}
      </div>
      {description && <p style={{ fontSize: 'var(--text-md)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)', maxWidth: 640 }}>{description}</p>}
    </div>
  );
}
