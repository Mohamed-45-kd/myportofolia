One-line: status pill for project state, availability, dashboard row status.

```jsx
<Badge tone="success" dot>Available for work</Badge>
```

Tones map to the semantic colour set. Use `Tag` instead when the pill is a technology label.
