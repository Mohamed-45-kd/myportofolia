/**
 * Primary action control.
 * @startingPoint section="Core" subtitle="Buttons, icon buttons and link buttons" viewport="700x220"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** primary = gradient CTA, secondary = card surface, ghost = bare, outline = brand hairline, danger = destructive. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  /** Lucide icon name rendered before the label. */
  icon?: string;
  /** Lucide icon name rendered after the label. */
  iconRight?: string;
  disabled?: boolean;
  /** Swaps the leading icon for a spinner and blocks clicks. */
  loading?: boolean;
  fullWidth?: boolean;
  /** Render as another element, e.g. "a" for a link button. */
  as?: 'button' | 'a';
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
