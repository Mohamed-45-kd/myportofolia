One-line: portrait for the about section, message threads and admin header.

```jsx
<Avatar name="Mohamed Weli Jama" size="lg" ring status="online" />
```
