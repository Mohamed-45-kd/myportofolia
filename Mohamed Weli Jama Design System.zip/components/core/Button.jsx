import React from 'react';
import { Icon } from './Icon.jsx';

const SIZES = {
  sm: { h: 34, px: 'var(--space-3)', fs: 'var(--text-sm)', gap: 6, icon: 15 },
  md: { h: 42, px: 'var(--space-5)', fs: 'var(--text-sm)', gap: 8, icon: 17 },
  lg: { h: 52, px: 'var(--space-7)', fs: 'var(--text-md)', gap: 10, icon: 19 },
};

const VARIANTS = {
  primary: {
    background: 'var(--gradient-brand)', color: '#fff',
    border: '1px solid transparent', boxShadow: 'var(--glow-brand)',
  },
  secondary: {
    background: 'var(--surface-card)', color: 'var(--text-primary)',
    border: '1px solid var(--border-subtle)', boxShadow: 'var(--inset-hairline)',
  },
  ghost: {
    background: 'transparent', color: 'var(--text-secondary)',
    border: '1px solid transparent', boxShadow: 'none',
  },
  outline: {
    background: 'transparent', color: 'var(--brand-primary)',
    border: '1px solid var(--border-brand)', boxShadow: 'none',
  },
  danger: {
    background: 'var(--danger-500)', color: '#fff',
    border: '1px solid transparent', boxShadow: '0 8px 24px -10px rgba(255,77,94,.7)',
  },
};

export function Button({
  children, variant = 'primary', size = 'md', icon, iconRight,
  disabled = false, loading = false, fullWidth = false, as = 'button',
  style, onClick, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const off = disabled || loading;
  const Tag = as;

  return (
    <Tag
      onClick={off ? undefined : onClick}
      disabled={Tag === 'button' ? off : undefined}
      aria-busy={loading || undefined}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={{
        display: fullWidth ? 'flex' : 'inline-flex', width: fullWidth ? '100%' : undefined,
        alignItems: 'center', justifyContent: 'center', gap: s.gap,
        height: s.h, padding: `0 ${s.px}`, borderRadius: 'var(--radius-md)',
        fontFamily: 'var(--font-body)', fontSize: s.fs, fontWeight: 'var(--weight-semibold)',
        letterSpacing: 'var(--track-snug)', whiteSpace: 'nowrap', cursor: off ? 'not-allowed' : 'pointer',
        opacity: off ? 0.45 : 1, textDecoration: 'none',
        transition: 'transform var(--dur-fast) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard), background var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
        transform: off ? 'none' : press ? 'scale(.985)' : hover ? 'translateY(-2px)' : 'none',
        ...v,
        ...(hover && !off && variant === 'primary' ? { boxShadow: 'var(--glow-brand-strong)' } : null),
        ...(hover && !off && variant === 'secondary' ? { background: 'var(--surface-hover)', borderColor: 'var(--border-strong)' } : null),
        ...(hover && !off && variant === 'ghost' ? { background: 'var(--surface-hover)', color: 'var(--text-primary)' } : null),
        ...(hover && !off && variant === 'outline' ? { background: 'rgba(10,132,255,.10)', borderColor: 'var(--brand-primary)' } : null),
        ...style,
      }}
      {...rest}
    >
      {loading ? <Spinner size={s.icon} /> : icon ? <Icon name={icon} size={s.icon} /> : null}
      {children}
      {iconRight && !loading ? <Icon name={iconRight} size={s.icon} /> : null}
    </Tag>
  );
}

function Spinner({ size }) {
  return (
    <span
      style={{
        width: size, height: size, borderRadius: '50%', flex: '0 0 auto',
        border: '2px solid rgba(255,255,255,.28)', borderTopColor: 'currentColor',
        animation: 'mwj-spin .7s linear infinite',
      }}
    >
      <style>{'@keyframes mwj-spin{to{transform:rotate(360deg)}}'}</style>
    </span>
  );
}
