/**
 * Brand icon. Renders a Lucide glyph at the brand's 1.75px stroke weight.
 */
export interface IconProps {
  /** Lucide icon name, kebab-case (e.g. "arrow-up-right", "code-2"). */
  name: string;
  /** Pixel box. Default 20. */
  size?: number;
  /** Stroke width. Default 1.75 — the brand weight. */
  stroke?: number;
  /** Stroke colour. Default currentColor. */
  color?: string;
  style?: React.CSSProperties;
}
export function Icon(props: IconProps): JSX.Element;
