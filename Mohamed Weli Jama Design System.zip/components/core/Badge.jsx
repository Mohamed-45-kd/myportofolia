import React from 'react';
import { Icon } from './Icon.jsx';

const TONES = {
  brand:   { bg: 'rgba(10,132,255,.12)', fg: 'var(--brand-accent)', bd: 'rgba(10,132,255,.30)' },
  neutral: { bg: 'var(--surface-inset)',  fg: 'var(--text-muted)',   bd: 'var(--border-subtle)' },
  success: { bg: 'var(--success-surface)', fg: 'var(--success-500)', bd: 'rgba(34,211,154,.30)' },
  warning: { bg: 'var(--warning-surface)', fg: 'var(--warning-500)', bd: 'rgba(255,176,32,.30)' },
  danger:  { bg: 'var(--danger-surface)',  fg: 'var(--danger-500)',  bd: 'rgba(255,77,94,.30)' },
};

export function Badge({ children, tone = 'neutral', size = 'md', dot = false, icon, style, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  const sm = size === 'sm';
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: sm ? 5 : 6,
        height: sm ? 20 : 24, padding: sm ? '0 7px' : '0 10px',
        borderRadius: 'var(--radius-pill)', background: t.bg, color: t.fg,
        border: `1px solid ${t.bd}`, fontFamily: 'var(--font-body)',
        fontSize: sm ? 'var(--text-2xs)' : 'var(--text-xs)', fontWeight: 'var(--weight-semibold)',
        letterSpacing: '0.02em', whiteSpace: 'nowrap', ...style,
      }}
      {...rest}
    >
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.fg, flex: '0 0 auto' }} />}
      {icon && <Icon name={icon} size={sm ? 11 : 13} />}
      {children}
    </span>
  );
}
