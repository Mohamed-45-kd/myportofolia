One-line: the container surface for everything — projects, dashboard panels, form groups.

```jsx
<Card interactive>
  <CardHeader title="Traffic" subtitle="Last 30 days" action={<IconButton icon="more-horizontal" label="More" variant="ghost" />} />
  …
</Card>
```

Never stack two cards' shadows; nest with `padding="none"` + a divider instead. `glow` is for one featured card only.
