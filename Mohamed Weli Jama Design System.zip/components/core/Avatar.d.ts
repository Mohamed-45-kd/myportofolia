/** Circular portrait; falls back to gradient initials when `src` is absent. */
export interface AvatarProps {
  src?: string;
  /** Used for alt text and initials fallback. */
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
  /** Brand ring + accent glow. */
  ring?: boolean;
  status?: 'online' | 'busy' | 'offline';
  style?: React.CSSProperties;
}
export function Avatar(props: AvatarProps): JSX.Element;
