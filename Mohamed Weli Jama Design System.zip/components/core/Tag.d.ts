/** Technology / keyword chip. Monospace by design — tags read as code. */
export interface TagProps {
  children?: React.ReactNode;
  active?: boolean;
  size?: 'sm' | 'md';
  /** Renders a remove affordance. */
  onRemove?: (e: React.MouseEvent) => void;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function Tag(props: TagProps): JSX.Element;
