/**
 * The brand's container surface: #111A27, 1px slate hairline, 14px radius, glassy top inset.
 * @startingPoint section="Core" subtitle="Card surface with header and hover lift" viewport="700x260"
 */
export interface CardProps {
  children?: React.ReactNode;
  padding?: 'none' | 'sm' | 'md' | 'lg';
  /** Enables the hover lift + brand border. Use for anything clickable. */
  interactive?: boolean;
  /** Adds the accent glow — reserve for one featured card per view. */
  glow?: boolean;
  as?: 'div' | 'a' | 'article' | 'section';
  href?: string;
  style?: React.CSSProperties;
}
export function Card(props: CardProps): JSX.Element;

export interface CardHeaderProps {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  /** Right-aligned control, usually an IconButton or Button. */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export function CardHeader(props: CardHeaderProps): JSX.Element;
