One-line: brand lockup for navbars, footers and the admin sidebar.

```jsx
<Logo variant="lockup" size={36} src="../../assets/logo-lockup.png" />
```

The supplied artwork is raster on near-black — do not place `variant="mark"` on a light surface without a dark plate. Never redraw the monogram.
