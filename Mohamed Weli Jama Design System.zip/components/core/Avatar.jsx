import React from 'react';

const SIZES = { xs: 24, sm: 32, md: 40, lg: 56, xl: 88 };

export function Avatar({ src, name = '', size = 'md', ring = false, status, style, ...rest }) {
  const px = typeof size === 'number' ? size : (SIZES[size] || SIZES.md);
  const initials = name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  return (
    <span style={{ position: 'relative', display: 'inline-flex', flex: '0 0 auto', ...style }} {...rest}>
      <span style={{
        width: px, height: px, borderRadius: 'var(--radius-pill)', overflow: 'hidden',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: src ? 'var(--surface-inset)' : 'var(--gradient-brand)',
        color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-bold)',
        fontSize: Math.max(10, px * 0.38), letterSpacing: '0.02em',
        border: ring ? '2px solid var(--brand-primary)' : '1px solid var(--border-subtle)',
        boxShadow: ring ? 'var(--glow-accent)' : 'none',
      }}>
        {src ? <img src={src} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : initials}
      </span>
      {status && (
        <span style={{
          position: 'absolute', right: -1, bottom: -1, width: Math.max(8, px * 0.26), height: Math.max(8, px * 0.26),
          borderRadius: '50%', border: '2px solid var(--surface-card)',
          background: status === 'online' ? 'var(--success-500)' : status === 'busy' ? 'var(--warning-500)' : 'var(--text-faint)',
        }} />
      )}
    </span>
  );
}
