One-line: the standard section opener — numbered mono eyebrow, display heading, muted description.

```jsx
<SectionHeading eyebrow="03 / Projects" title="Selected work" description="Practical products shipped end to end." />
```

Number the eyebrows across a page (`01 /`, `02 /`…) — it's a brand motif, not decoration.
