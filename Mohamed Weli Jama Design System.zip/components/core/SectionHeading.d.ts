/** Eyebrow + heading + description block that opens every portfolio section. */
export interface SectionHeadingProps {
  /** Tracked-uppercase mono label with a leading rule, e.g. "02 / PROJECTS". */
  eyebrow?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  align?: 'left' | 'center';
  /** Trailing control aligned to the heading baseline. */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export function SectionHeading(props: SectionHeadingProps): JSX.Element;
