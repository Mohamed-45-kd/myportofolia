import React from 'react';

/* The MWJ monogram lockup. The provided artwork is a raster lockup on near-black,
   so the mark is used as an <img>; the wordmark next to it is live type. */
export function Logo({ src = 'assets/logo-lockup.png', variant = 'lockup', size = 36, showMission = false, style, ...rest }) {
  if (variant === 'mark') {
    return <img src={src} alt="Mohamed Weli Jama" style={{ width: size, height: size, objectFit: 'cover', objectPosition: 'center 22%', borderRadius: 'var(--radius-sm)', ...style }} {...rest} />;
  }
  if (variant === 'wordmark') {
    return (
      <span style={{ display: 'grid', gap: 2, ...style }} {...rest}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-bold)', fontSize: size * 0.44, letterSpacing: 'var(--track-eyebrow)', color: 'var(--text-primary)', lineHeight: 1 }}>MOHAMED</span>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-bold)', fontSize: size * 0.44, letterSpacing: 'var(--track-eyebrow)', lineHeight: 1, background: 'var(--gradient-brand)', WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>WELI JAMA</span>
      </span>
    );
  }
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-3)', ...style }} {...rest}>
      <img src={src} alt="" style={{ width: size, height: size, objectFit: 'cover', objectPosition: 'center 22%', borderRadius: 'var(--radius-sm)' }} />
      <span style={{ display: 'grid', gap: showMission ? 3 : 1 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--weight-bold)', fontSize: 13, letterSpacing: '0.16em', color: 'var(--text-primary)', lineHeight: 1 }}>MOHAMED WELI JAMA</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.12em', color: 'var(--text-muted)', lineHeight: 1.3 }}>
          {showMission ? 'MY MISSION IS TO DIGITALIZE OUR COUNTRY' : 'SOFTWARE & WEB DEVELOPER'}
        </span>
      </span>
    </span>
  );
}
