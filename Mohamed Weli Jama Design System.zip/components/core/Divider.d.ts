/** Hairline rule, optionally with a tracked-out centre label (logo lockup motif). */
export interface DividerProps {
  label?: string;
  orientation?: 'horizontal' | 'vertical';
  /** Fades out at both ends. */
  gradient?: boolean;
  style?: React.CSSProperties;
}
export function Divider(props: DividerProps): JSX.Element;
