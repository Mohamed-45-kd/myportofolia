/** Small status pill. */
export interface BadgeProps {
  children?: React.ReactNode;
  tone?: 'brand' | 'neutral' | 'success' | 'warning' | 'danger';
  size?: 'sm' | 'md';
  /** Leading status dot. */
  dot?: boolean;
  /** Leading Lucide icon name. */
  icon?: string;
  style?: React.CSSProperties;
}
export function Badge(props: BadgeProps): JSX.Element;
