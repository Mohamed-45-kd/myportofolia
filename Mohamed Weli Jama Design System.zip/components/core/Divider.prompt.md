One-line: hairline separator; `label` renders the tracked-uppercase centre label from the logo lockup.

```jsx
<Divider label="Or continue with" gradient />
```
