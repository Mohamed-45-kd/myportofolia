One-line: monospace chip for technologies and filters (React, Laravel, PostgreSQL).

```jsx
<Tag active onClick={() => filter('react')}>React</Tag>
```

Always monospace — never use `Badge` for a tech label, and never use `Tag` for status.
