One-line: icon-only square control for toolbars, card actions and table rows.

```jsx
<IconButton icon="github" label="GitHub" variant="ghost" />
```

`active` gives the brand-tinted pressed state used for toggles (theme switch, grid/list view).
