import React from 'react';
import { Icon } from './Icon.jsx';

const BOX = { sm: 32, md: 38, lg: 46 };

export function IconButton({ icon, label, variant = 'secondary', size = 'md', active = false, disabled = false, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const box = BOX[size] || BOX.md;
  const base = variant === 'ghost'
    ? { background: 'transparent', border: '1px solid transparent', color: 'var(--text-muted)' }
    : variant === 'primary'
      ? { background: 'var(--gradient-brand)', border: '1px solid transparent', color: '#fff', boxShadow: 'var(--glow-brand)' }
      : { background: 'var(--surface-card)', border: '1px solid var(--border-subtle)', color: 'var(--text-secondary)', boxShadow: 'var(--inset-hairline)' };

  return (
    <button
      type="button" aria-label={label} aria-pressed={active || undefined} disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      title={label}
      style={{
        width: box, height: box, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 'var(--radius-md)', cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1,
        transition: 'background var(--dur-base) var(--ease-standard), color var(--dur-base) var(--ease-standard), border-color var(--dur-base) var(--ease-standard)',
        ...base,
        ...(active ? { background: 'rgba(10,132,255,.14)', borderColor: 'var(--border-brand)', color: 'var(--brand-accent)' } : null),
        ...(hover && !disabled && !active ? { background: 'var(--surface-hover)', color: 'var(--text-primary)', borderColor: variant === 'ghost' ? 'transparent' : 'var(--border-strong)' } : null),
        ...style,
      }}
      {...rest}
    >
      <Icon name={icon} size={size === 'sm' ? 15 : size === 'lg' ? 20 : 17} />
    </button>
  );
}
