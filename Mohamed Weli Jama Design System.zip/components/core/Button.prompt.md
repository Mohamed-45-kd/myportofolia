One-line: the brand's action control — one `primary` gradient CTA per view, everything else `secondary`/`ghost`.

```jsx
<Button variant="primary" size="lg" iconRight="arrow-up-right">View projects</Button>
<Button variant="secondary" icon="download">Résumé</Button>
```

Variants: `primary` (brand gradient + glow), `secondary`, `ghost`, `outline`, `danger`. Sizes `sm|md|lg`. Hover lifts 2px, press scales to .985. Use `as="a"` + `href` for link buttons.
