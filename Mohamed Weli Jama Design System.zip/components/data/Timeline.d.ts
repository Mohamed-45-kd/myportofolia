/**
 * Vertical rail for experience, education and achievements.
 * @startingPoint section="Portfolio" subtitle="Experience & education timeline" viewport="700x400"
 */
export interface TimelineItem {
  id?: string;
  title: string;
  /** Organisation / school, shown in accent blue. */
  org?: string;
  /** e.g. "2023 — Present". Rendered monospace. */
  period?: string;
  description?: string;
  tags?: string[];
  /** Lucide icon for the node chip. Default "briefcase". */
  icon?: string;
  /** Highlights the node in brand blue. Use for the present role. */
  current?: boolean;
}
export interface TimelineProps {
  items?: TimelineItem[];
  style?: React.CSSProperties;
}
export function Timeline(props: TimelineProps): JSX.Element;
