One-line: the dashboard KPI tile — four across on desktop.

```jsx
<StatCard label="Profile views" value="12,480" delta="+12.4%" icon="eye" footnote="vs. last 30 days" />
```
