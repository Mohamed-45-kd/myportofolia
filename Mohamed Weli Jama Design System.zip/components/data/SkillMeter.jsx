import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { ProgressBar } from '../feedback/ProgressBar.jsx';

export function SkillMeter({ name, level, icon, note, style }) {
  return (
    <div style={{
      display: 'grid', gap: 'var(--space-3)', padding: 'var(--space-4) var(--space-5)',
      background: 'var(--surface-card)', border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)', boxShadow: 'var(--inset-hairline)', ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
        {icon && <Icon name={icon} size={17} color="var(--brand-accent)" />}
        <span style={{ flex: 1, fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)', color: 'var(--text-primary)' }}>{name}</span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-muted)' }}>{level}%</span>
      </div>
      <ProgressBar value={level} size="sm" />
      {note && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{note}</span>}
    </div>
  );
}
