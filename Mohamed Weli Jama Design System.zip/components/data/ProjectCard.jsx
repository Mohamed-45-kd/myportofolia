import React from 'react';
import { Card } from '../core/Card.jsx';
import { Tag } from '../core/Tag.jsx';
import { Badge } from '../core/Badge.jsx';
import { Icon } from '../core/Icon.jsx';

export function ProjectCard({ title, summary, thumbnail, tags = [], status, year, featured = false, onOpen, style }) {
  return (
    <Card interactive padding="none" glow={featured} onClick={onOpen} style={{ overflow: 'hidden', display: 'grid', gridTemplateRows: 'auto 1fr', ...style }}>
      <div style={{
        position: 'relative', aspectRatio: '16/10', background: thumbnail ? `center/cover no-repeat url(${thumbnail})` : 'var(--surface-inset)',
        borderBottom: '1px solid var(--border-subtle)',
      }}>
        {!thumbnail && (
          <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', gap: 6, color: 'var(--text-faint)', backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)', backgroundSize: '28px 28px' }}>
            <Icon name="image" size={22} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)' }}>SCREENSHOT</span>
          </div>
        )}
        {(status || featured) && (
          <div style={{ position: 'absolute', top: 'var(--space-3)', left: 'var(--space-3)', display: 'flex', gap: 6 }}>
            {featured && <Badge tone="brand" size="sm" icon="star">Featured</Badge>}
            {status && <Badge tone="neutral" size="sm">{status}</Badge>}
          </div>
        )}
      </div>
      <div style={{ display: 'grid', gap: 'var(--space-3)', padding: 'var(--space-5)', alignContent: 'start' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 'var(--space-4)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>{title}</h3>
          {year && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{year}</span>}
        </div>
        {summary && <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', lineHeight: 'var(--leading-relaxed)' }}>{summary}</p>}
        {tags.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 2 }}>
            {tags.map((t) => <Tag key={t} size="sm">{t}</Tag>)}
          </div>
        )}
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: 'var(--space-2)', fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)', color: 'var(--brand-accent)' }}>
          Read case study <Icon name="arrow-up-right" size={15} />
        </span>
      </div>
    </Card>
  );
}
