import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function Table({ columns = [], rows = [], onSort, sort, dense = false, style }) {
  return (
    <div style={{ border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', background: 'var(--surface-card)', boxShadow: 'var(--inset-hairline)', ...style }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'var(--font-body)' }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} onClick={c.sortable && onSort ? () => onSort(c.key) : undefined}
                style={{
                  textAlign: c.align || 'left', padding: dense ? '10px 14px' : '13px 18px',
                  background: 'var(--surface-inset)', borderBottom: '1px solid var(--border-subtle)',
                  fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 'var(--weight-medium)',
                  letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-faint)',
                  whiteSpace: 'nowrap', cursor: c.sortable ? 'pointer' : 'default', width: c.width,
                }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                  {c.label}
                  {c.sortable && <Icon name={sort === c.key ? 'chevron-up' : 'chevrons-up-down'} size={12} color={sort === c.key ? 'var(--brand-accent)' : 'var(--text-faint)'} />}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => <Row key={r.id ?? i} row={r} columns={columns} dense={dense} last={i === rows.length - 1} />)}
        </tbody>
      </table>
    </div>
  );
}

function Row({ row, columns, dense, last }) {
  const [hover, setHover] = React.useState(false);
  return (
    <tr onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ background: hover ? 'var(--surface-hover)' : 'transparent', transition: 'background var(--dur-fast) var(--ease-standard)' }}>
      {columns.map((c) => (
        <td key={c.key} style={{
          textAlign: c.align || 'left', padding: dense ? '10px 14px' : '15px 18px',
          borderBottom: last ? 'none' : '1px solid var(--border-subtle)',
          fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', verticalAlign: 'middle',
        }}>
          {c.render ? c.render(row) : row[c.key]}
        </td>
      ))}
    </tr>
  );
}
