/**
 * Portfolio gallery tile — the most important component in the system.
 * @startingPoint section="Portfolio" subtitle="Project gallery tile with tech tags" viewport="700x420"
 */
export interface ProjectCardProps {
  title: React.ReactNode;
  summary?: React.ReactNode;
  /** Image URL. Omitted renders the grid-paper placeholder. */
  thumbnail?: string;
  /** Technology labels, rendered as monospace Tags. */
  tags?: string[];
  /** e.g. "Live", "In progress". */
  status?: string;
  year?: string | number;
  /** Adds the accent glow + Featured badge. One per gallery. */
  featured?: boolean;
  onOpen?: () => void;
  style?: React.CSSProperties;
}
export function ProjectCard(props: ProjectCardProps): JSX.Element;
