/** Single KPI tile for the dashboard overview. */
export interface StatCardProps {
  label: React.ReactNode;
  value: React.ReactNode;
  /** e.g. "+12.4%". */
  delta?: string;
  deltaTone?: 'success' | 'danger' | 'warning';
  /** Lucide icon name in the corner chip. */
  icon?: string;
  footnote?: React.ReactNode;
  style?: React.CSSProperties;
}
export function StatCard(props: StatCardProps): JSX.Element;
