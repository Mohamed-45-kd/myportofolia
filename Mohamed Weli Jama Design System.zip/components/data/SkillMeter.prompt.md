One-line: skills-section row combining a label, monospace percentage and progress track.

```jsx
<SkillMeter name="Laravel / PHP" level={90} icon="server" note="Primary backend stack" />
```
