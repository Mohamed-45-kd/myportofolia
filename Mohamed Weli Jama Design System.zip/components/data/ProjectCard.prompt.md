One-line: the project gallery tile; three across on desktop, one on mobile.

```jsx
<ProjectCard title="Somtel Self-Care" summary="Airtime and data self-service for 400k subscribers."
  tags={['Laravel','Vue','MySQL']} status="Live" year="2025" featured />
```

Leave `thumbnail` empty rather than inventing artwork — the grid placeholder is intentional.
