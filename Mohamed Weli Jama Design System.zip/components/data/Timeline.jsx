import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Tag } from '../core/Tag.jsx';

export function Timeline({ items = [], style }) {
  return (
    <ol style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 'var(--space-7)', ...style }}>
      {items.map((it, i) => (
        <li key={it.id || i} style={{ display: 'grid', gridTemplateColumns: '34px 1fr', gap: 'var(--space-5)', position: 'relative' }}>
          {i < items.length - 1 && <span style={{ position: 'absolute', left: 17, top: 36, bottom: -32, width: 1, background: 'var(--border-subtle)' }} />}
          <span style={{
            width: 34, height: 34, display: 'grid', placeItems: 'center', borderRadius: 'var(--radius-sm)',
            background: it.current ? 'rgba(10,132,255,.12)' : 'var(--surface-inset)',
            border: `1px solid ${it.current ? 'var(--border-brand)' : 'var(--border-subtle)'}`, zIndex: 1,
          }}>
            <Icon name={it.icon || 'briefcase'} size={16} color={it.current ? 'var(--brand-accent)' : 'var(--text-muted)'} />
          </span>
          <div style={{ display: 'grid', gap: 6, paddingBottom: 2 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)', flexWrap: 'wrap' }}>
              <strong style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)' }}>{it.title}</strong>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{it.period}</span>
            </div>
            {it.org && <span style={{ fontSize: 'var(--text-sm)', color: 'var(--brand-accent)', fontWeight: 'var(--weight-medium)' }}>{it.org}</span>}
            {it.description && <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', lineHeight: 'var(--leading-relaxed)', maxWidth: 620 }}>{it.description}</p>}
            {it.tags && it.tags.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 4 }}>{it.tags.map((t) => <Tag key={t} size="sm">{t}</Tag>)}</div>
            )}
          </div>
        </li>
      ))}
    </ol>
  );
}
