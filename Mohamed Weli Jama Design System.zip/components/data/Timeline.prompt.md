One-line: experience/education rail; mark the present role with `current`.

```jsx
<Timeline items={[{title:'Software Developer',org:'Freelance',period:'2023 — Present',current:true,tags:['Laravel','React']}]} />
```
