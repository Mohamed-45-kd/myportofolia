One-line: the admin list view — projects, messages, technologies.

```jsx
<Table sort="date" onSort={setSort} columns={[
  {key:'title',label:'Project',sortable:true},
  {key:'status',label:'Status',render:(r)=><Badge tone="success" dot>{r.status}</Badge>},
]} rows={rows} />
```

Wrap status and tech cells in `Badge`/`Tag` rather than plain text.
