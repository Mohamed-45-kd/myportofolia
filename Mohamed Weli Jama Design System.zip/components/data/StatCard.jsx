import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function StatCard({ label, value, delta, deltaTone = 'success', icon, footnote, style }) {
  return (
    <div style={{
      position: 'relative', overflow: 'hidden', display: 'grid', gap: 'var(--space-3)',
      padding: 'var(--space-5)', background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-sm), var(--inset-hairline)', ...style,
    }}>
      <div style={{ position: 'absolute', inset: 0, background: 'var(--gradient-card-edge)', pointerEvents: 'none' }} />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-4)' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-muted)' }}>{label}</span>
        {icon && (
          <span style={{ width: 32, height: 32, display: 'grid', placeItems: 'center', borderRadius: 'var(--radius-sm)', background: 'rgba(10,132,255,.10)', border: '1px solid var(--border-brand)' }}>
            <Icon name={icon} size={16} color="var(--brand-accent)" />
          </span>
        )}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)' }}>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-tight)', lineHeight: 1 }}>{value}</span>
        {delta && (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: `var(--${deltaTone}-500)` }}>
            <Icon name={deltaTone === 'danger' ? 'trending-down' : 'trending-up'} size={13} />{delta}
          </span>
        )}
      </div>
      {footnote && <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{footnote}</span>}
    </div>
  );
}
