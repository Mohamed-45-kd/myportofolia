/**
 * Data table for the admin dashboard. Mono uppercase headers, hairline rows, hover tint.
 * @startingPoint section="Data" subtitle="Admin data table with sortable headers" viewport="700x300"
 */
export interface TableColumn {
  key: string;
  label: React.ReactNode;
  align?: 'left' | 'center' | 'right';
  width?: number | string;
  sortable?: boolean;
  /** Custom cell renderer — receives the whole row. */
  render?: (row: any) => React.ReactNode;
}
export interface TableProps {
  columns?: TableColumn[];
  rows?: any[];
  /** Currently sorted column key. */
  sort?: string;
  onSort?: (key: string) => void;
  /** Tighter row height for long lists. */
  dense?: boolean;
  style?: React.CSSProperties;
}
export function Table(props: TableProps): JSX.Element;
