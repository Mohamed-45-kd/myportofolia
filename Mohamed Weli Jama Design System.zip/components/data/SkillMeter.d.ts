/** Named proficiency row for the skills section. */
export interface SkillMeterProps {
  name: React.ReactNode;
  /** 0–100. */
  level: number;
  /** Lucide icon name. */
  icon?: string;
  /** e.g. "4 years, 11 shipped projects". */
  note?: React.ReactNode;
  style?: React.CSSProperties;
}
export function SkillMeter(props: SkillMeterProps): JSX.Element;
