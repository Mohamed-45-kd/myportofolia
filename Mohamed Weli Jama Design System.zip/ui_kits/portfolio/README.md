# UI kit — Public portfolio site

Interactive recreation of the public-facing portfolio. Open `index.html`.

## Screens / surfaces
| Surface | Where |
| --- | --- |
| Sticky header + theme toggle | `Navbar` (components/navigation) |
| Hero | `Sections.jsx → Hero` |
| About + achievements | `Sections.jsx → About` |
| Skills | `Sections.jsx → Skills` |
| Project gallery, filterable | `Sections.jsx → Work` |
| Project case study | `Sections.jsx → CaseStudy` |
| Services | `Sections.jsx → Services` |
| Experience / education tabs | `Sections.jsx → Experience` |
| Blog index | `Sections.jsx → Blog` |
| Contact form (submits to success state) | `Sections.jsx → Contact` |
| Footer with mission lockup | `Footer` (components/navigation) |

## What is interactive
- Nav links smooth-scroll; the logo returns to the top.
- Theme toggle flips `data-theme` between dark and light on `<html>`.
- Project gallery filters by status (All / Live / Archived) — filtering to an empty set shows `EmptyState`.
- Clicking a project opens the case-study view with Overview / Stack / Results tabs.
- The contact form submits to an inline success `Alert`; the header CTA fires a `Toast`.

## Content note
Project names, clients, metrics and posts are **plausible placeholders** written to match the
brand's tone. Replace them with Mohamed's real work before this is used as reference.

Screenshots are intentionally left as the grid placeholder — no real project imagery was supplied.
