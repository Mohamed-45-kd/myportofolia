window.PF = {
  nav: [{id:'home',label:'Home'},{id:'about',label:'About'},{id:'work',label:'Work'},{id:'services',label:'Services'},{id:'blog',label:'Blog'},{id:'contact',label:'Contact'}],
  projects: [
    {id:'somtel',title:'Somtel Self-Care',year:'2025',status:'Live',featured:true,summary:'Airtime top-up, data bundles and billing history for 400k subscribers.',tags:['Laravel','Vue','MySQL','Redis'],role:'Full-stack developer',client:'Somtel',duration:'7 months',
     problem:'Subscribers had to visit a branch or call support to top up or check a balance. Support handled 3,000+ repetitive calls a week.',
     approach:'Built a self-service portal on top of the existing billing API, starting with the three journeys that generated the most calls: top-up, bundle purchase and balance history.',
     outcome:[{k:'Support calls',v:'-62%'},{k:'Monthly active users',v:'118k'},{k:'Avg. top-up time',v:'41s'}]},
    {id:'clinic',title:'Hargeisa Clinic Booking',year:'2024',status:'Live',summary:'Appointment booking and patient records for a six-clinic network.',tags:['React','Node','PostgreSQL'],role:'Lead developer',client:'Private network',duration:'5 months'},
    {id:'fees',title:'School Fee Portal',year:'2024',status:'Live',summary:'Fee tracking and mobile-money reconciliation for 2,400 students.',tags:['Next.js','Prisma','Stripe'],role:'Solo developer',client:'Al-Nuur Schools',duration:'3 months'},
    {id:'logistics',title:'Berbera Freight Tracker',year:'2023',status:'Live',summary:'Container tracking dashboard for a port logistics operator.',tags:['Laravel','Livewire','MySQL']},
    {id:'agri',title:'Agri Market Prices',year:'2023',status:'Live',summary:'Daily crop price index collected by SMS from 40 markets.',tags:['PHP','Twilio','Chart.js']},
    {id:'gov',title:'Municipal Permit Desk',year:'2022',status:'Archived',summary:'Digital permit applications replacing a paper intake process.',tags:['Laravel','Bootstrap']}
  ],
  skills: [
    {name:'Laravel / PHP',level:92,icon:'server',note:'Primary backend stack'},
    {name:'React / Next.js',level:88,icon:'code-2',note:'Most client front-ends'},
    {name:'PostgreSQL / MySQL',level:85,icon:'database'},
    {name:'Tailwind CSS',level:90,icon:'palette'},
    {name:'Node / Express',level:76,icon:'terminal'},
    {name:'Docker & CI',level:68,icon:'container',note:'Deploying to VPS and Fly.io'}
  ],
  services: [
    {icon:'globe',title:'Web application development',body:'End-to-end builds: data model, API, interface, deployment. Laravel or Next.js depending on the team that will maintain it.'},
    {icon:'smartphone',title:'Responsive front-end work',body:'Turning designs into accessible, fast interfaces that hold up on the 3G connections most of my users are on.'},
    {icon:'workflow',title:'Digitalizing manual processes',body:'Paper intake, spreadsheet tracking, WhatsApp order books — mapped, then replaced with something auditable.'},
    {icon:'wrench',title:'Maintenance & handover',body:'Taking over an existing codebase, documenting it, and leaving it in a state your own team can run.'}
  ],
  experience: [
    {title:'Software Developer',org:'Freelance · Hargeisa',period:'2023 — Present',current:true,description:'Building web platforms for telecom, health, education and logistics clients across Somaliland.',tags:['Laravel','React','PostgreSQL']},
    {title:'Web Developer',org:'Tabaarak ICT Solutions',period:'2022 — 2023',description:'Delivered client sites and internal tools; owned the front-end of three government-facing portals.',tags:['PHP','Bootstrap','MySQL']},
    {title:'Junior Developer (Intern)',org:'Somtel',period:'2021 — 2022',description:'Maintained internal reporting tools and wrote the first version of the billing API client.',tags:['PHP','jQuery']}
  ],
  education: [
    {title:'BSc Computer Science',org:'University of Hargeisa',period:'2019 — 2023',icon:'graduation-cap',description:'Graduated with distinction. Final project: an SMS-based agricultural price index, later shipped as a public site.'},
    {title:'Meta Front-End Developer Certificate',org:'Coursera',period:'2023',icon:'award'}
  ],
  achievements: [
    {icon:'trophy',title:'National Innovation Challenge — 2nd place',meta:'2024 · Ministry of Telecommunication'},
    {icon:'users',title:'Mentored 30+ junior developers',meta:'2022 — Present · local dev community'},
    {icon:'git-merge',title:'Open-source contributor',meta:'Laravel ecosystem packages'},
    {icon:'presentation',title:'Speaker — Hargeisa Tech Meetup',meta:'2023, 2024, 2025'}
  ],
  posts: [
    {title:'Shipping software on a 3G budget',date:'12 Aug 2026',read:'6 min',tag:'Performance',excerpt:'Every kilobyte is a decision when your median user is on a shared 3G connection. Here is the budget I hold myself to.'},
    {title:'Why I still reach for Laravel first',date:'28 Jul 2026',read:'8 min',tag:'Backend',excerpt:'Not because it is fashionable — because the teams I hand projects to can actually maintain it.'},
    {title:'Digitalizing a paper permit desk',date:'03 Jul 2026',read:'11 min',tag:'Case study',excerpt:'What I learned mapping a municipal process before writing a single line of code.'}
  ]
};
