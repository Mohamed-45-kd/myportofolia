const { Button, IconButton, Badge, Tag, Card, CardHeader, Avatar, Divider, SectionHeading,
        Tabs, ProjectCard, Timeline, SkillMeter, StatCard, Icon, Input, Textarea, Select, Alert, EmptyState } = window.MohamedWeliJamaDesignSystem_8944ce;

const LOGO = '../../assets/logo-lockup.png';
const wrap = { maxWidth: 'var(--layout-max)', margin: '0 auto', padding: '0 var(--layout-gutter)' };
const section = { padding: 'var(--section-y) 0' };

function Hero({ onNavigate }) {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', padding: 'var(--space-13) 0 var(--space-12)' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'var(--gradient-hero-glow)', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)', backgroundSize: '28px 28px', maskImage: 'radial-gradient(70% 60% at 50% 30%,#000,transparent)', WebkitMaskImage: 'radial-gradient(70% 60% at 50% 30%,#000,transparent)', opacity: .7, pointerEvents: 'none' }} />
      <div style={{ ...wrap, position: 'relative', display: 'grid', gridTemplateColumns: '1.15fr .85fr', gap: 'var(--space-11)', alignItems: 'center' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)', justifyItems: 'start' }}>
          <Badge tone="success" dot>Available for new projects</Badge>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-hero)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-tight)', lineHeight: 1.02, margin: 0 }}>
            Software that<br />actually ships —{' '}
            <span style={{ background: 'var(--gradient-text)', WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>and gets used.</span>
          </h1>
          <p style={{ fontSize: 'var(--text-lg)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)', maxWidth: 540 }}>
            I'm Mohamed Weli Jama, a software and web developer in Hargeisa. I build practical
            digital products for telecom, health, education and government teams.
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', flexWrap: 'wrap' }}>
            <Button size="lg" iconRight="arrow-up-right" onClick={() => onNavigate('work')}>View selected work</Button>
            <Button size="lg" variant="secondary" icon="download">Download résumé</Button>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-6)', marginTop: 'var(--space-4)' }}>
            {[['14', 'Products shipped'], ['4', 'Years building'], ['9', 'Clients served']].map(([n, l]) => (
              <div key={l} style={{ display: 'grid', gap: 2 }}>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-tight)' }}>{n}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-faint)' }}>{l}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ display: 'grid', gap: 'var(--space-4)', justifyItems: 'center' }}>
          <img src={LOGO} alt="Mohamed Weli Jama" style={{ width: '100%', maxWidth: 340, aspectRatio: '1', objectFit: 'contain', borderRadius: 'var(--radius-2xl)', border: '1px solid var(--border-subtle)', background: '#000', boxShadow: 'var(--shadow-xl), var(--glow-accent)' }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', letterSpacing: 'var(--track-wide)', color: 'var(--brand-accent)' }}>&lt;/&gt; MY MISSION IS TO DIGITALIZE OUR COUNTRY</span>
        </div>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" style={{ ...section, background: 'var(--bg-subtle)', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
      <div style={{ ...wrap, display: 'grid', gridTemplateColumns: '.9fr 1.1fr', gap: 'var(--space-11)', alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)' }}>
          <SectionHeading eyebrow="01 / About" title="A developer who finishes things" />
          <p style={{ fontSize: 'var(--text-md)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)' }}>
            I started writing PHP for a telecom internal tool in 2021 and never stopped. Most of my
            work since then has been the same shape: a process someone runs on paper, in a spreadsheet
            or over WhatsApp, turned into something auditable that a small team can maintain.
          </p>
          <p style={{ fontSize: 'var(--text-md)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)' }}>
            I care about two things more than anything else: that the thing gets shipped, and that
            it still works six months after I hand it over.
          </p>
          <div style={{ display: 'flex', gap: 'var(--space-3)' }}>
            {['github', 'linkedin', 'twitter', 'mail'].map((i) => <IconButton key={i} icon={i} label={i} />)}
          </div>
        </div>
        <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
          <Card glow>
            <div style={{ display: 'flex', gap: 'var(--space-5)', alignItems: 'center' }}>
              <Avatar name="Mohamed Weli Jama" size="xl" ring />
              <div style={{ display: 'grid', gap: 5 }}>
                <strong style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-lg)' }}>Mohamed Weli Jama</strong>
                <span style={{ fontSize: 'var(--text-sm)', color: 'var(--brand-accent)' }}>Software &amp; Web Developer</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>Hargeisa, Somaliland · GMT+3</span>
              </div>
            </div>
            <Divider style={{ margin: 'var(--space-5) 0' }} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
              {[['Focus', 'Web platforms'], ['Stack', 'Laravel · React'], ['Languages', 'Somali · English · Arabic'], ['Working style', 'Remote or on-site']].map(([k, v]) => (
                <div key={k} style={{ display: 'grid', gap: 3 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-faint)' }}>{k}</span>
                  <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{v}</span>
                </div>
              ))}
            </div>
          </Card>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
            {window.PF.achievements.slice(0, 4).map((a) => (
              <Card key={a.title} padding="sm">
                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'flex-start' }}>
                  <Icon name={a.icon} size={18} color="var(--brand-accent)" />
                  <div style={{ display: 'grid', gap: 3 }}>
                    <span style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)' }}>{a.title}</span>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>{a.meta}</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section style={section}>
      <div style={{ ...wrap, display: 'grid', gap: 'var(--space-9)' }}>
        <SectionHeading eyebrow="02 / Skills" title="Technologies I work in daily"
          description="Percentages reflect how much of my shipped work leans on each — not a self-assessment." />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'var(--space-4)' }}>
          {window.PF.skills.map((s) => <SkillMeter key={s.name} {...s} />)}
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--space-2)' }}>
          {['TypeScript','Livewire','Alpine.js','Inertia','Redis','Nginx','Git','Figma','Vite','REST','Stripe','Twilio','Chart.js','Linux'].map((t) => <Tag key={t}>{t}</Tag>)}
        </div>
      </div>
    </section>
  );
}

function Work({ onOpen }) {
  const [filter, setFilter] = React.useState('all');
  const all = window.PF.projects;
  const list = filter === 'all' ? all : all.filter((p) => p.status.toLowerCase() === filter);
  return (
    <section style={{ ...section, background: 'var(--bg-subtle)', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
      <div style={{ ...wrap, display: 'grid', gap: 'var(--space-8)' }}>
        <SectionHeading eyebrow="03 / Projects" title="Selected work"
          description="Six of fourteen shipped products. Each one replaced a manual process."
          action={<Tabs variant="pill" value={filter} onChange={setFilter} items={[{id:'all',label:'All'},{id:'live',label:'Live'},{id:'archived',label:'Archived'}]} />} />
        {list.length === 0 ? (
          <EmptyState icon="filter-x" title="Nothing under that filter" description="Try “All” to see every project." />
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'var(--space-6)' }}>
            {list.map((p) => <ProjectCard key={p.id} {...p} onOpen={() => onOpen(p)} />)}
          </div>
        )}
      </div>
    </section>
  );
}

function Services() {
  return (
    <section style={section}>
      <div style={{ ...wrap, display: 'grid', gap: 'var(--space-9)' }}>
        <SectionHeading align="center" eyebrow="04 / Services" title="How I can help"
          description="Four ways clients usually bring me in. Fixed scope where possible, retainer where it isn't." />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 'var(--space-5)' }}>
          {window.PF.services.map((s, i) => (
            <Card key={s.title} interactive>
              <div style={{ display: 'flex', gap: 'var(--space-4)', alignItems: 'flex-start' }}>
                <span style={{ width: 44, height: 44, flex: '0 0 auto', display: 'grid', placeItems: 'center', borderRadius: 'var(--radius-md)', background: 'rgba(10,132,255,.10)', border: '1px solid var(--border-brand)' }}>
                  <Icon name={s.icon} size={20} color="var(--brand-accent)" />
                </span>
                <div style={{ display: 'grid', gap: 'var(--space-2)' }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--space-3)' }}>
                    <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)' }}>{s.title}</h3>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>0{i + 1}</span>
                  </div>
                  <p style={{ fontSize: 'var(--text-sm)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)' }}>{s.body}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function Experience() {
  const [tab, setTab] = React.useState('experience');
  return (
    <section style={{ ...section, background: 'var(--bg-subtle)', borderTop: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)' }}>
      <div style={{ ...wrap, display: 'grid', gridTemplateColumns: '.8fr 1.2fr', gap: 'var(--space-11)', alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)', position: 'sticky', top: 'calc(var(--nav-h) + 32px)' }}>
          <SectionHeading eyebrow="05 / Path" title="Experience &amp; education" />
          <Tabs value={tab} onChange={setTab} items={[{id:'experience',label:'Experience',icon:'briefcase'},{id:'education',label:'Education',icon:'graduation-cap'}]} />
        </div>
        <Timeline items={tab === 'experience' ? window.PF.experience : window.PF.education} />
      </div>
    </section>
  );
}

function Blog() {
  return (
    <section style={section}>
      <div style={{ ...wrap, display: 'grid', gap: 'var(--space-8)' }}>
        <SectionHeading eyebrow="06 / Writing" title="Notes from the work"
          action={<Button variant="ghost" iconRight="arrow-right">All posts</Button>} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'var(--space-5)' }}>
          {window.PF.posts.map((p) => (
            <Card key={p.title} interactive>
              <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 'var(--space-3)' }}>
                  <Badge tone="brand" size="sm">{p.tag}</Badge>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>{p.read}</span>
                </div>
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)', lineHeight: 1.3 }}>{p.title}</h3>
                <p style={{ fontSize: 'var(--text-sm)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)' }}>{p.excerpt}</p>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>{p.date}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = React.useState(false);
  return (
    <section style={{ ...section, background: 'var(--bg-subtle)', borderTop: '1px solid var(--border-subtle)' }}>
      <div style={{ ...wrap, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-11)', alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)' }}>
          <SectionHeading eyebrow="07 / Contact" title="Let's build something useful"
            description="Tell me what process you're trying to replace. I reply to every message within two working days." />
          <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
            {[['mail','mohamed@weli.dev'],['phone','+252 63 000 0000'],['map-pin','Hargeisa, Somaliland'],['clock','Mon–Sat, 09:00–18:00 GMT+3']].map(([i, v]) => (
              <div key={v} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                <Icon name={i} size={16} color="var(--brand-accent)" />
                <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <Card padding="lg">
          {sent ? (
            <Alert tone="success" title="Message sent">Thanks — I'll be in touch within two working days.</Alert>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: 'grid', gap: 'var(--space-5)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                <Input label="Name" icon="user" placeholder="Your name" required />
                <Input label="Email" icon="mail" placeholder="you@company.com" required />
              </div>
              <Select label="What do you need?" options={['Web application development','Responsive front-end work','Digitalizing a manual process','Maintenance & handover']} />
              <Textarea label="Project details" rows={5} placeholder="What are you replacing, and by when?" />
              <Button type="submit" size="lg" fullWidth iconRight="send">Send message</Button>
            </form>
          )}
        </Card>
      </div>
    </section>
  );
}

function CaseStudy({ project, onBack }) {
  const [tab, setTab] = React.useState('overview');
  const p = project;
  return (
    <div style={{ ...wrap, padding: 'var(--space-9) var(--layout-gutter) var(--space-12)', display: 'grid', gap: 'var(--space-8)' }}>
      <Button variant="ghost" icon="arrow-left" onClick={onBack} style={{ justifySelf: 'start' }}>Back to work</Button>
      <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
        <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
          <Badge tone="success" dot>{p.status}</Badge>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>{p.year}</span>
        </div>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-4xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-tight)', lineHeight: 1.05, margin: 0 }}>{p.title}</h1>
        <p style={{ fontSize: 'var(--text-lg)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)', maxWidth: 680 }}>{p.summary}</p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>{p.tags.map((t) => <Tag key={t}>{t}</Tag>)}</div>
      </div>
      <div style={{ aspectRatio: '21/9', borderRadius: 'var(--radius-xl)', border: '1px solid var(--border-subtle)', background: 'var(--surface-card)', backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)', backgroundSize: '28px 28px', display: 'grid', placeItems: 'center', gap: 8, color: 'var(--text-faint)' }}>
        <Icon name="image" size={26} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-eyebrow)' }}>PROJECT SCREENSHOT</span>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 'var(--space-9)', alignItems: 'start' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)' }}>
          <Tabs value={tab} onChange={setTab} items={[{id:'overview',label:'Overview'},{id:'stack',label:'Stack',icon:'layers'},{id:'results',label:'Results',icon:'trending-up'}]} />
          {tab === 'overview' && (
            <div style={{ display: 'grid', gap: 'var(--space-6)', maxWidth: 680 }}>
              <Block title="The problem" body={p.problem || 'A manual process that could not scale with the number of people relying on it.'} />
              <Block title="The approach" body={p.approach || 'Mapped the existing process with the people who run it, then replaced the highest-volume journeys first.'} />
            </div>
          )}
          {tab === 'stack' && (
            <div style={{ display: 'grid', gap: 'var(--space-4)', maxWidth: 680 }}>
              {p.tags.map((t) => (
                <Card key={t} padding="sm">
                  <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                    <Icon name="box" size={17} color="var(--brand-accent)" />
                    <strong style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)' }}>{t}</strong>
                  </div>
                </Card>
              ))}
            </div>
          )}
          {tab === 'results' && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'var(--space-4)' }}>
              {(p.outcome || [{k:'Outcome',v:'—'}]).map((o) => <StatCard key={o.k} label={o.k} value={o.v} />)}
            </div>
          )}
        </div>
        <Card>
          <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
            {[['Client', p.client || '—'], ['Role', p.role || '—'], ['Duration', p.duration || '—'], ['Year', p.year]].map(([k, v]) => (
              <div key={k} style={{ display: 'grid', gap: 3 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', textTransform: 'uppercase', color: 'var(--text-faint)' }}>{k}</span>
                <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{v}</span>
              </div>
            ))}
            <Divider />
            <Button fullWidth iconRight="external-link">Visit live site</Button>
            <Button fullWidth variant="secondary" icon="github">Source</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Block({ title, body }) {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-3)' }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>{title}</h2>
      <p style={{ fontSize: 'var(--text-md)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-muted)' }}>{body}</p>
    </div>
  );
}

Object.assign(window, { Hero, About, Skills, Work, Services, Experience, Blog, Contact, CaseStudy });
