const { Button, IconButton, Badge, Tag, Card, CardHeader, Avatar, Divider, Icon,
        Table, StatCard, SkillMeter, Input, Textarea, Select, Checkbox, Switch,
        Tabs, Breadcrumbs, Pagination, Alert, EmptyState, Modal, ProgressBar, Tooltip } = window.MohamedWeliJamaDesignSystem_8944ce;

function Topbar({ title, crumbs, onNew, onToggleTheme, theme, onToggleSidebar }) {
  return (
    <header style={{
      display: 'flex', alignItems: 'center', gap: 'var(--space-4)', height: 68, flex: '0 0 auto',
      padding: '0 var(--space-7)', background: 'var(--surface-raised)',
      borderBottom: '1px solid var(--border-subtle)',
    }}>
      <IconButton icon="panel-left" label="Toggle sidebar" variant="ghost" onClick={onToggleSidebar} />
      <div style={{ display: 'grid', gap: 3 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>{title}</h1>
        {crumbs && <Breadcrumbs items={crumbs} />}
      </div>
      <div style={{ flex: 1 }} />
      <Input size="sm" icon="search" placeholder="Search…" containerStyle={{ width: 220 }} />
      <Tooltip label="Toggle theme"><IconButton icon={theme === 'dark' ? 'sun' : 'moon'} label="Theme" variant="ghost" onClick={onToggleTheme} /></Tooltip>
      <Tooltip label="3 unread"><IconButton icon="bell" label="Notifications" variant="ghost" /></Tooltip>
      {onNew && <Button size="sm" icon="plus" onClick={onNew}>New project</Button>}
      <Divider orientation="vertical" style={{ height: 28 }} />
      <Avatar name="Mohamed Weli Jama" size="sm" status="online" />
    </header>
  );
}

function Dashboard({ onGo }) {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-6)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 'var(--space-4)' }}>
        <StatCard label="Profile views" value="12,480" delta="+12.4%" icon="eye" footnote="vs. last 30 days" />
        <StatCard label="Projects published" value="14" delta="+2" icon="folder-git-2" footnote="2 drafts pending" />
        <StatCard label="New messages" value="3" delta="-8%" deltaTone="danger" icon="mail" footnote="oldest 2 days" />
        <StatCard label="Uptime" value="99.9%" icon="activity" footnote="all deployed apps" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 'var(--space-5)' }}>
        <Card>
          <CardHeader title="Views by week" subtitle="Last 12 weeks" action={<Tabs variant="pill" value="12w" onChange={() => {}} items={[{id:'4w',label:'4w'},{id:'12w',label:'12w'},{id:'1y',label:'1y'}]} />} />
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: 180, padding: 'var(--space-4) 0 0' }}>
            {[38,44,41,58,52,64,60,72,68,84,79,96].map((h, i) => (
              <div key={i} style={{ flex: 1, display: 'grid', gap: 6, justifyItems: 'center' }}>
                <div style={{ width: '100%', height: h * 1.6, borderRadius: '6px 6px 2px 2px', background: i === 11 ? 'var(--gradient-brand)' : 'linear-gradient(180deg,rgba(10,132,255,.45),rgba(10,132,255,.06))', border: '1px solid var(--border-brand)', boxShadow: i === 11 ? 'var(--glow-accent)' : 'none' }} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: 'var(--text-faint)' }}>W{i + 1}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHeader title="Top technologies" subtitle="By project count" />
          <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
            {window.AD.technologies.slice(0, 4).map((t) => (
              <ProgressBar key={t.id} label={t.name} value={t.level} showValue />
            ))}
          </div>
        </Card>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-5)' }}>
        <Card padding="none">
          <div style={{ padding: 'var(--space-5) var(--space-5) var(--space-4)' }}>
            <CardHeader title="Recent messages" subtitle="3 unread" style={{ marginBottom: 0 }}
              action={<Button size="sm" variant="ghost" iconRight="arrow-right" onClick={() => onGo('messages')}>Inbox</Button>} />
          </div>
          <div>
            {window.AD.messages.slice(0, 3).map((m, i) => (
              <div key={m.id} style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center', padding: 'var(--space-4) var(--space-5)', borderTop: '1px solid var(--border-subtle)' }}>
                <Avatar name={m.name} size="sm" />
                <div style={{ display: 'grid', gap: 2, flex: 1, minWidth: 0 }}>
                  <span style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)' }}>{m.name}</span>
                  <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.subject}</span>
                </div>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>{m.time}</span>
                {m.unread && <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--brand-primary)' }} />}
              </div>
            ))}
          </div>
        </Card>
        <div style={{ display: 'grid', gap: 'var(--space-5)', alignContent: 'start' }}>
          <Alert tone="warning" title="2 projects still in draft" action={<Button size="sm" variant="ghost" onClick={() => onGo('projects')}>Review drafts</Button>}>
            Draft projects are hidden from the public gallery.
          </Alert>
          <Card>
            <CardHeader title="Quick actions" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-3)' }}>
              <Button variant="secondary" icon="folder-plus" onClick={() => onGo('projects')}>Add project</Button>
              <Button variant="secondary" icon="file-plus">Write post</Button>
              <Button variant="secondary" icon="layers" onClick={() => onGo('technologies')}>Add technology</Button>
              <Button variant="secondary" icon="upload">Upload résumé</Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Projects({ onEdit, onNew }) {
  const [sort, setSort] = React.useState('updated');
  const [filter, setFilter] = React.useState('all');
  const [page, setPage] = React.useState(1);
  const rows = window.AD.projects.filter((p) => filter === 'all' || p.status.toLowerCase() === filter);
  return (
    <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', flexWrap: 'wrap' }}>
        <Tabs variant="pill" value={filter} onChange={setFilter} items={[{id:'all',label:'All'},{id:'published',label:'Published'},{id:'draft',label:'Drafts'},{id:'archived',label:'Archived'}]} />
        <div style={{ flex: 1 }} />
        <Select size="sm" options={['Sort: last updated','Sort: most viewed','Sort: A–Z']} containerStyle={{ width: 190 }} />
        <Button size="sm" variant="secondary" icon="download">Export CSV</Button>
        <Button size="sm" icon="plus" onClick={onNew}>New project</Button>
      </div>
      {rows.length === 0 ? (
        <EmptyState icon="filter-x" title="No projects in this state" description="Switch the filter or create a new project." action={<Button icon="plus" onClick={onNew}>New project</Button>} />
      ) : (
        <React.Fragment>
          <Table sort={sort} onSort={setSort} rows={rows} columns={[
            { key: 'title', label: 'Project', sortable: true, render: (r) => (
              <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
                <span style={{ width: 34, height: 34, borderRadius: 'var(--radius-sm)', background: 'var(--surface-inset)', border: '1px solid var(--border-subtle)', display: 'grid', placeItems: 'center' }}>
                  <Icon name="image" size={14} color="var(--text-faint)" />
                </span>
                <div style={{ display: 'grid', gap: 2 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-primary)', fontWeight: 'var(--weight-semibold)' }}>
                    {r.title}{r.featured && <Badge size="sm" tone="brand" icon="star">Featured</Badge>}
                  </span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>/{r.slug}</span>
                </div>
              </div>) },
            { key: 'stack', label: 'Stack', render: (r) => <Tag size="sm">{r.stack}</Tag> },
            { key: 'status', label: 'Status', render: (r) => <Badge size="sm" dot tone={r.status === 'Published' ? 'success' : r.status === 'Draft' ? 'warning' : 'neutral'}>{r.status}</Badge> },
            { key: 'views', label: 'Views', align: 'right', sortable: true },
            { key: 'updated', label: 'Updated', sortable: true },
            { key: 'a', label: '', align: 'right', width: 108, render: (r) => (
              <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                <IconButton size="sm" variant="ghost" icon="external-link" label="Preview" />
                <IconButton size="sm" variant="ghost" icon="pencil" label="Edit" onClick={() => onEdit(r)} />
                <IconButton size="sm" variant="ghost" icon="trash-2" label="Delete" onClick={() => onEdit(r, 'delete')} />
              </div>) },
          ]} />
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-4)' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-faint)' }}>SHOWING {rows.length} OF 14</span>
            <Pagination page={page} pages={3} onChange={setPage} />
          </div>
        </React.Fragment>
      )}
    </div>
  );
}

function ProjectEditor({ project, onBack, onSave }) {
  const [tab, setTab] = React.useState('content');
  const [featured, setFeatured] = React.useState(!!(project && project.featured));
  const [live, setLive] = React.useState(!project || project.status === 'Published');
  return (
    <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)' }}>
        <Button variant="ghost" icon="arrow-left" onClick={onBack}>Back to projects</Button>
        <div style={{ flex: 1 }} />
        <Button variant="secondary" icon="eye">Preview</Button>
        <Button icon="check" onClick={onSave}>Save changes</Button>
      </div>
      <Tabs value={tab} onChange={setTab} items={[{id:'content',label:'Content',icon:'file-text'},{id:'media',label:'Media',icon:'image'},{id:'meta',label:'SEO & meta',icon:'search'}]} />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 'var(--space-5)', alignItems: 'start' }}>
        <Card padding="lg">
          {tab === 'content' && (
            <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
              <Input label="Project title" defaultValue={project ? project.title : ''} placeholder="e.g. Somtel Self-Care" />
              <Input label="Slug" icon="link" defaultValue={project ? project.slug : ''} hint="Lowercase, hyphen-separated." />
              <Textarea label="Summary" rows={3} defaultValue={project ? 'Airtime top-up, data bundles and billing history for 400k subscribers.' : ''} />
              <Textarea label="The problem" rows={4} placeholder="What was broken before this existed?" />
              <Textarea label="The approach" rows={4} placeholder="How did you replace it?" />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4)' }}>
                <Input label="Client" defaultValue={project ? 'Somtel' : ''} />
                <Input label="Duration" defaultValue={project ? '7 months' : ''} />
              </div>
            </div>
          )}
          {tab === 'media' && (
            <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
              <EmptyState icon="upload-cloud" title="Drop project screenshots here" description="PNG or WebP, 1600px wide minimum. First image becomes the gallery thumbnail." action={<Button variant="secondary" icon="folder-open">Browse files</Button>} />
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 'var(--space-3)' }}>
                {[0,1,2,3].map((i) => (
                  <div key={i} style={{ aspectRatio: '4/3', borderRadius: 'var(--radius-md)', border: '1px dashed var(--border-strong)', background: 'var(--surface-inset)', display: 'grid', placeItems: 'center', color: 'var(--text-faint)' }}>
                    <Icon name="plus" size={18} />
                  </div>
                ))}
              </div>
            </div>
          )}
          {tab === 'meta' && (
            <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
              <Input label="Meta title" defaultValue={project ? project.title + ' — Case study' : ''} suffix="58/60" />
              <Textarea label="Meta description" rows={3} defaultValue="Airtime and data self-service for 400k Somtel subscribers, built on Laravel and Vue." />
              <Input label="Canonical URL" icon="link" defaultValue={project ? 'https://weli.dev/work/' + project.slug : ''} />
              <Alert tone="info" title="Indexing">Published projects are added to the sitemap within an hour.</Alert>
            </div>
          )}
        </Card>
        <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
          <Card>
            <CardHeader title="Publishing" />
            <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
              <Select label="Status" options={['Published','Draft','Archived']} />
              <Switch label="Visible on public gallery" checked={live} onChange={setLive} />
              <Checkbox label="Feature on homepage" description="Only one project can be featured." checked={featured} onChange={setFeatured} />
              <Divider />
              <Button variant="danger" fullWidth icon="trash-2">Delete project</Button>
            </div>
          </Card>
          <Card>
            <CardHeader title="Technologies" subtitle="Shown as tags on the case study" />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 'var(--space-4)' }}>
              {['Laravel','Vue','MySQL','Redis'].map((t) => <Tag key={t} size="sm" onRemove={() => {}}>{t}</Tag>)}
            </div>
            <Select size="sm" options={['Add technology…','React','Next.js','Docker','Tailwind CSS']} />
          </Card>
        </div>
      </div>
    </div>
  );
}

function Technologies({ onNew }) {
  return (
    <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
      <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center' }}>
        <Input size="sm" icon="search" placeholder="Filter technologies…" containerStyle={{ width: 260 }} />
        <div style={{ flex: 1 }} />
        <Button size="sm" icon="plus" onClick={onNew}>Add technology</Button>
      </div>
      <Table rows={window.AD.technologies} columns={[
        { key: 'name', label: 'Technology', sortable: true, render: (r) => <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--text-primary)', fontWeight: 'var(--weight-medium)' }}>{r.name}</span> },
        { key: 'category', label: 'Category', render: (r) => <Badge size="sm" tone="neutral">{r.category}</Badge> },
        { key: 'projects', label: 'Projects', align: 'right', sortable: true },
        { key: 'level', label: 'Proficiency', width: 220, render: (r) => <ProgressBar value={r.level} size="sm" /> },
        { key: 'a', label: '', align: 'right', width: 76, render: () => (
          <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
            <IconButton size="sm" variant="ghost" icon="pencil" label="Edit" />
            <IconButton size="sm" variant="ghost" icon="trash-2" label="Delete" />
          </div>) },
      ]} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 'var(--space-4)' }}>
        {window.AD.technologies.slice(0, 3).map((t) => <SkillMeter key={t.id} name={t.name} level={t.level} icon="box" note={t.projects + ' projects'} />)}
      </div>
    </div>
  );
}

function Messages() {
  const [sel, setSel] = React.useState(window.AD.messages[0]);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '340px 1fr', gap: 'var(--space-5)', alignItems: 'start' }}>
      <Card padding="none">
        <div style={{ padding: 'var(--space-4)', borderBottom: '1px solid var(--border-subtle)' }}>
          <Input size="sm" icon="search" placeholder="Search messages…" />
        </div>
        {window.AD.messages.map((m) => {
          const on = sel && sel.id === m.id;
          return (
            <button key={m.id} onClick={() => setSel(m)} style={{
              display: 'grid', gap: 5, width: '100%', textAlign: 'left', cursor: 'pointer',
              padding: 'var(--space-4)', border: 'none', borderBottom: '1px solid var(--border-subtle)',
              borderLeft: on ? '2px solid var(--brand-primary)' : '2px solid transparent',
              background: on ? 'rgba(10,132,255,.08)' : 'transparent', fontFamily: 'var(--font-body)',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <Avatar name={m.name} size="xs" />
                <span style={{ flex: 1, fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-semibold)', color: 'var(--text-primary)' }}>{m.name}</span>
                {m.unread && <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--brand-primary)' }} />}
              </div>
              <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-secondary)', fontWeight: 'var(--weight-medium)' }}>{m.subject}</span>
              <span style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.preview}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', color: 'var(--text-faint)' }}>{m.time}</span>
            </button>
          );
        })}
      </Card>
      {sel ? (
        <Card padding="lg">
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 'var(--space-4)', marginBottom: 'var(--space-5)' }}>
            <Avatar name={sel.name} size="lg" />
            <div style={{ display: 'grid', gap: 4, flex: 1 }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>{sel.subject}</h2>
              <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{sel.name} · <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)' }}>{sel.email}</span></span>
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}><Badge size="sm" tone="brand">{sel.tag}</Badge><Badge size="sm">{sel.time}</Badge></div>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              <IconButton icon="archive" label="Archive" variant="ghost" />
              <IconButton icon="star" label="Star" variant="ghost" />
              <IconButton icon="trash-2" label="Delete" variant="ghost" />
            </div>
          </div>
          <Divider />
          <p style={{ fontSize: 'var(--text-md)', lineHeight: 'var(--leading-relaxed)', color: 'var(--text-secondary)', margin: 'var(--space-5) 0' }}>
            {sel.preview} Let me know what a realistic timeline looks like and what you would need
            from us to get started. Happy to jump on a call this week.
          </p>
          <Divider />
          <div style={{ display: 'grid', gap: 'var(--space-4)', marginTop: 'var(--space-5)' }}>
            <Textarea label="Reply" rows={4} placeholder="Write your reply…" />
            <div style={{ display: 'flex', gap: 'var(--space-3)', justifyContent: 'flex-end' }}>
              <Button variant="ghost" icon="paperclip">Attach</Button>
              <Button iconRight="send">Send reply</Button>
            </div>
          </div>
        </Card>
      ) : <EmptyState icon="mail-open" title="No message selected" description="Pick a message from the list." />}
    </div>
  );
}

function Settings() {
  const [dark, setDark] = React.useState(true);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-5)', alignItems: 'start', maxWidth: 980 }}>
      <Card padding="lg">
        <CardHeader title="Profile" subtitle="Shown across the public site" />
        <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
          <div style={{ display: 'flex', gap: 'var(--space-4)', alignItems: 'center' }}>
            <Avatar name="Mohamed Weli Jama" size="lg" ring />
            <Button size="sm" variant="secondary" icon="upload">Replace photo</Button>
          </div>
          <Input label="Display name" defaultValue="Mohamed Weli Jama" />
          <Input label="Role" defaultValue="Software & Web Developer" />
          <Textarea label="Mission statement" rows={2} defaultValue="My mission is to digitalize our Country." hint="Rendered in tracked uppercase in the footer." />
          <Input label="Location" icon="map-pin" defaultValue="Hargeisa, Somaliland" />
        </div>
      </Card>
      <div style={{ display: 'grid', gap: 'var(--space-5)' }}>
        <Card padding="lg">
          <CardHeader title="Appearance" />
          <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
            <Switch label="Dark theme by default" checked={dark} onChange={setDark} />
            <Checkbox label="Respect visitor system preference" checked description="Overrides the default above." />
            <Select label="Accent" options={['Primary — #0A84FF','Accent — #00C2FF','Deep blue — #0066FF']} />
          </div>
        </Card>
        <Card padding="lg">
          <CardHeader title="Danger zone" />
          <div style={{ display: 'grid', gap: 'var(--space-4)' }}>
            <Alert tone="danger" title="Irreversible actions">Removing all content cannot be undone.</Alert>
            <Button variant="danger" icon="trash-2">Delete all content</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Login({ onLogin }) {
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', position: 'relative', overflow: 'hidden', padding: 'var(--space-7)' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'var(--gradient-hero-glow)' }} />
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(var(--grid-line) 1px,transparent 1px),linear-gradient(90deg,var(--grid-line) 1px,transparent 1px)', backgroundSize: '28px 28px', maskImage: 'radial-gradient(60% 50% at 50% 40%,#000,transparent)', WebkitMaskImage: 'radial-gradient(60% 50% at 50% 40%,#000,transparent)' }} />
      <Card padding="lg" style={{ position: 'relative', width: '100%', maxWidth: 420, boxShadow: 'var(--shadow-xl), var(--glow-accent)' }}>
        <div style={{ display: 'grid', gap: 'var(--space-6)', justifyItems: 'center', textAlign: 'center' }}>
          <img src="../../assets/logo-lockup.png" alt="" style={{ width: 64, height: 64, objectFit: 'cover', objectPosition: 'center 22%', borderRadius: 'var(--radius-md)' }} />
          <div style={{ display: 'grid', gap: 6 }}>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'var(--text-xl)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--track-snug)' }}>Portfolio admin</h1>
            <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>Private dashboard. Authorised access only.</p>
          </div>
          <form onSubmit={(e) => { e.preventDefault(); onLogin(); }} style={{ display: 'grid', gap: 'var(--space-4)', width: '100%', textAlign: 'left' }}>
            <Input label="Email" icon="mail" defaultValue="mohamed@weli.dev" />
            <Input label="Password" icon="lock" type="password" defaultValue="••••••••••" />
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--space-4)' }}>
              <Checkbox label="Keep me signed in" checked />
              <a href="#" style={{ fontSize: 'var(--text-xs)' }}>Forgot password?</a>
            </div>
            <Button type="submit" size="lg" fullWidth iconRight="arrow-right">Sign in</Button>
          </form>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', letterSpacing: 'var(--track-wide)', color: 'var(--text-faint)' }}>&lt;/&gt; MY MISSION IS TO DIGITALIZE OUR COUNTRY</span>
        </div>
      </Card>
    </div>
  );
}

Object.assign(window, { Topbar, Dashboard, Projects, ProjectEditor, Technologies, Messages, Settings, Login });
