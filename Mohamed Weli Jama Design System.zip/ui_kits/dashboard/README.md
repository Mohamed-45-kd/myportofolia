# UI kit — Private admin dashboard

Interactive recreation of the private management dashboard / CMS. Open `index.html`.
It boots on the **sign-in screen** — submit the pre-filled form to enter the shell.

## Screens / surfaces
| Surface | Where |
| --- | --- |
| Sign in | `Screens.jsx → Login` |
| App shell (sidebar + topbar) | `SidebarNav` + `Screens.jsx → Topbar` |
| Dashboard overview | `Screens.jsx → Dashboard` |
| Projects list (CMS) | `Screens.jsx → Projects` |
| Project editor (content / media / SEO) | `Screens.jsx → ProjectEditor` |
| Technology management | `Screens.jsx → Technologies` |
| Messages inbox + reply | `Screens.jsx → Messages` |
| Settings + danger zone | `Screens.jsx → Settings` |
| Delete confirmation | `Modal` (components/feedback) |

## What is interactive
- Sign in → shell; sidebar collapses to the 72px icon rail via the topbar toggle.
- Sidebar navigates between Dashboard, Projects, Technologies, Messages and Settings.
- Projects: filter tabs, sortable headers, pagination, row actions. Edit or New opens the editor;
  Delete opens the confirm modal, which fires a success toast.
- Editor tabs switch Content / Media / SEO; Save returns to the list with a toast.
- Messages: selecting a thread loads the reading pane and reply composer.
- Theme toggle in the topbar flips dark/light.

Surfaces with no supplied design (Analytics, Services, Blog posts, Experience) render a
deliberate placeholder rather than an invented layout.
