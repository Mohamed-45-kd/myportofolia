window.AD = {
  groups: [
    {label:'Overview',items:[{id:'dashboard',label:'Dashboard',icon:'layout-dashboard'},{id:'analytics',label:'Analytics',icon:'bar-chart-3'}]},
    {label:'Content',items:[
      {id:'projects',label:'Projects',icon:'folder-git-2',count:14},
      {id:'technologies',label:'Technologies',icon:'layers',count:24},
      {id:'services',label:'Services',icon:'briefcase',count:4},
      {id:'blog',label:'Blog posts',icon:'file-text',count:8},
      {id:'experience',label:'Experience',icon:'milestone',count:3}]},
    {label:'Inbox',items:[{id:'messages',label:'Messages',icon:'mail',count:3}]},
    {label:'System',items:[{id:'settings',label:'Settings',icon:'settings'}]}
  ],
  projects: [
    {id:1,title:'Somtel Self-Care',slug:'somtel-self-care',stack:'Laravel',status:'Published',featured:true,views:'4,120',updated:'2 hours ago'},
    {id:2,title:'Hargeisa Clinic Booking',slug:'hargeisa-clinic-booking',stack:'React',status:'Published',views:'2,884',updated:'Yesterday'},
    {id:3,title:'School Fee Portal',slug:'school-fee-portal',stack:'Next.js',status:'Published',views:'1,902',updated:'3 days ago'},
    {id:4,title:'Berbera Freight Tracker',slug:'berbera-freight-tracker',stack:'Laravel',status:'Published',views:'1,340',updated:'1 week ago'},
    {id:5,title:'Agri Market Prices',slug:'agri-market-prices',stack:'PHP',status:'Draft',views:'—',updated:'2 weeks ago'},
    {id:6,title:'Municipal Permit Desk',slug:'municipal-permit-desk',stack:'Laravel',status:'Archived',views:'812',updated:'3 months ago'}
  ],
  technologies: [
    {id:1,name:'Laravel',category:'Backend',projects:7,level:92},
    {id:2,name:'React',category:'Frontend',projects:5,level:88},
    {id:3,name:'PostgreSQL',category:'Database',projects:4,level:85},
    {id:4,name:'Tailwind CSS',category:'Frontend',projects:9,level:90},
    {id:5,name:'Docker',category:'DevOps',projects:3,level:68}
  ],
  messages: [
    {id:1,name:'Amina Yusuf',email:'amina@alnuur.edu.so',subject:'Fee portal — second phase',preview:'We would like to add parent logins before the new term starts in October. Can you scope…',time:'12 min ago',unread:true,tag:'Web application development'},
    {id:2,name:'Khadar Ali',email:'k.ali@berberaport.so',subject:'Freight tracker maintenance',preview:'The container export is timing out on large date ranges. Are you available this week to…',time:'2 hours ago',unread:true,tag:'Maintenance & handover'},
    {id:3,name:'Sagal Ibrahim',email:'sagal@clinicnet.so',subject:'Booking system — SMS reminders',preview:'Patients keep missing appointments. Could we add an SMS reminder 24 hours before…',time:'Yesterday',unread:true,tag:'Web application development'},
    {id:4,name:'Mustafe Hassan',email:'mustafe@tabaarak.com',subject:'Contract work — Q4',preview:'We have three client sites lined up and would like to bring you on as a subcontractor…',time:'2 days ago',unread:false,tag:'Responsive front-end work'}
  ]
};
